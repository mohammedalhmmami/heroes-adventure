import XCTest

@testable import HeroesAdventure

/// Pure-logic tests for points, shop math and save/restore guards.
///
/// GameStore reads/writes UserDefaults.standard, so every test runs
/// against a clean slate: setUp snapshots all `ha.*` keys and clears
/// them, tearDown restores them. Nothing here touches SpriteKit or
/// SwiftUI, so these run in CI on a simulator.
final class GameStoreTests: XCTestCase {

    private let keys = [
        "ha.coins", "ha.gems", "ha.unlocked", "ha.stars", "ha.owned",
        "ha.hero", "ha.sound", "ha.music", "ha.daily",
    ]
    private var saved: [String: Any] = [:]

    override func setUp() {
        super.setUp()
        let d = UserDefaults.standard
        saved = [:]
        for key in keys {
            if let value = d.object(forKey: key) { saved[key] = value }
            d.removeObject(forKey: key)
        }
    }

    override func tearDown() {
        let d = UserDefaults.standard
        for key in keys { d.removeObject(forKey: key) }
        for (key, value) in saved { d.set(value, forKey: key) }
        super.tearDown()
    }

    // MARK: - Progress / save guards (AngryBirds GameProgress pattern)

    func testFreshStoreStartsAtLevel1() {
        let store = GameStore()
        XCTAssertEqual(store.unlockedLevel, 1)
        XCTAssertEqual(store.coins, 0)
        XCTAssertEqual(store.gems, 0)
        XCTAssertEqual(store.totalStars, 0)
    }

    func testCompleteLevelUnlocksOnlyTheNextLevel() {
        let store = GameStore()
        store.completeLevel(number: 1, stars: 2, coins: 10, gems: 5)
        XCTAssertEqual(store.unlockedLevel, 2)
        XCTAssertEqual(store.coins, 10)
        XCTAssertEqual(store.gems, 5)
        // Replaying an already-unlocked level must not unlock further.
        store.completeLevel(number: 1, stars: 3, coins: 10, gems: 5)
        XCTAssertEqual(store.unlockedLevel, 2)
    }

    func testCompleteLevelNeverUnlocksPast40() {
        let store = GameStore()
        store.completeLevel(number: 40, stars: 3, coins: 0, gems: 0)
        XCTAssertEqual(store.unlockedLevel, 1, "Completing level 40 must not raise unlocked past 40")
        XCTAssertEqual(store.stars(for: 40), 3)
    }

    func testCompleteLevelRejectsInvalidNumbers() {
        let store = GameStore()
        store.completeLevel(number: 0, stars: 3, coins: 100, gems: 100)
        store.completeLevel(number: 41, stars: 3, coins: 100, gems: 100)
        XCTAssertEqual(store.unlockedLevel, 1)
        XCTAssertEqual(store.coins, 0)
        XCTAssertEqual(store.gems, 0)
    }

    func testStarsOnlyImprove() {
        let store = GameStore()
        store.completeLevel(number: 5, stars: 1, coins: 0, gems: 0)
        XCTAssertEqual(store.stars(for: 5), 1)
        store.completeLevel(number: 5, stars: 3, coins: 0, gems: 0)
        XCTAssertEqual(store.stars(for: 5), 3)
        store.completeLevel(number: 5, stars: 1, coins: 0, gems: 0)
        XCTAssertEqual(store.stars(for: 5), 3, "A worse replay must not overwrite a better result")
    }

    func testUnlockedLevelClampedWhenLoadingCorruptValue() {
        UserDefaults.standard.set(99, forKey: "ha.unlocked")
        XCTAssertEqual(GameStore().unlockedLevel, 40)
        UserDefaults.standard.set(0, forKey: "ha.unlocked")
        XCTAssertEqual(GameStore().unlockedLevel, 1)
    }

    func testStarsClampedWhenLoadingCorruptValue() {
        let data = try? JSONEncoder().encode(["1": 9, "99": 3, "2": 2])
        UserDefaults.standard.set(data, forKey: "ha.stars")
        let store = GameStore()
        XCTAssertEqual(store.stars(for: 1), 3, "Stars above 3 clamp to 3")
        XCTAssertEqual(store.stars(for: 2), 2)
        XCTAssertEqual(store.stars(for: 99), 0, "Level 99 is outside 1...40 and must be dropped")
    }

    func testResetProgressRestoresDefaults() {
        let store = GameStore()
        store.completeLevel(number: 1, stars: 3, coins: 50, gems: 5)
        store.resetProgress()
        XCTAssertEqual(store.unlockedLevel, 1)
        XCTAssertEqual(store.coins, 0)
        XCTAssertEqual(store.gems, 0)
        XCTAssertEqual(store.totalStars, 0)
    }

    // MARK: - Shop math

    private func item(_ id: String) throws -> ShopItem {
        try XCTUnwrap(GameStore.shopItems.first { $0.id == id })
    }

    private func richStore(coins: Int = 10_000, gems: Int = 100) -> GameStore {
        let store = GameStore()
        store.addCoins(coins)
        store.addGems(gems)
        return store
    }

    func testSwordTiersRequirePreviousTier() throws {
        let store = richStore()
        let sword1 = try item("sword1")
        let sword2 = try item("sword2")
        XCTAssertEqual(store.swordDamage, 1)
        XCTAssertFalse(store.canBuy(sword2), "sword2 requires sword1")
        XCTAssertFalse(store.buy(sword2))
        XCTAssertTrue(store.buy(sword1))
        XCTAssertEqual(store.swordDamage, 2)
        XCTAssertTrue(store.canBuy(sword2))
        XCTAssertTrue(store.buy(sword2))
        XCTAssertEqual(store.swordDamage, 3)
        XCTAssertFalse(store.canBuy(sword1), "Already owned")
    }

    func testCannotBuyWithoutEnoughCurrency() throws {
        let store = GameStore()
        let sword1 = try item("sword1")
        XCTAssertFalse(store.canBuy(sword1))
        XCTAssertFalse(store.buy(sword1))
        XCTAssertEqual(store.coins, 0)
        store.addCoins(299)
        XCTAssertFalse(store.canBuy(sword1))
        store.addCoins(1)
        XCTAssertTrue(store.canBuy(sword1))
        XCTAssertTrue(store.buy(sword1))
        XCTAssertEqual(store.coins, 0, "Exact cost is deducted in full")
    }

    func testArmorRaisesMaxHeartsUpTo5() throws {
        let store = richStore()
        XCTAssertEqual(store.maxHearts, 3)
        let armor1 = try item("armor1")
        let armor2 = try item("armor2")
        XCTAssertFalse(store.buy(armor2), "armor2 requires armor1")
        XCTAssertTrue(store.buy(armor1))
        XCTAssertEqual(store.maxHearts, 4)
        XCTAssertTrue(store.buy(armor2))
        XCTAssertEqual(store.maxHearts, 5)
    }

    func testDoubleJumpAndDashUpgrades() throws {
        let store = richStore()
        XCTAssertFalse(store.hasDoubleJump)
        XCTAssertEqual(store.dashCooldown, 1.2, accuracy: 0.001)
        let doubleJump = try item("doubleJump")
        let dash = try item("dash1")
        XCTAssertTrue(store.buy(doubleJump))
        XCTAssertTrue(store.hasDoubleJump)
        XCTAssertTrue(store.buy(dash))
        XCTAssertEqual(store.dashCooldown, 1.0, accuracy: 0.001)
    }

    // MARK: - Daily bonus

    func testDailyBonusOnlyOncePerDay() {
        let store = GameStore()
        XCTAssertTrue(store.canClaimDailyBonus)
        XCTAssertTrue(store.claimDailyBonus())
        XCTAssertEqual(store.coins, 100)
        XCTAssertEqual(store.gems, 10)
        XCTAssertFalse(store.canClaimDailyBonus)
        XCTAssertFalse(store.claimDailyBonus())
        XCTAssertEqual(store.coins, 100, "Second claim the same day pays nothing")
    }
}
