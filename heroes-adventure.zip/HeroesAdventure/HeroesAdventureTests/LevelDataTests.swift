import CoreGraphics
import XCTest

@testable import HeroesAdventure

/// Pure-logic tests for the 40-level table.
///
/// These tests mirror `validate_levels.py` (same envelope, same gap
/// rule) in Swift, so CI catches a broken level the moment it is
/// introduced — instead of the user finding it on the device, as
/// happened with level 9 in v1.3 (unreachable platforms, found only by
/// the offline validator). No SpriteKit, no SwiftUI, no device: they
/// run in CI on a simulator.
///
/// Movement envelope — the REAL values from GameScene (locked tuning):
/// gravity 1470 pt/s^2, jump velocity 660 pt/s, move speed 360 pt/s.
/// Jump height = 660^2 / (2*1470) = 148.2pt; flat jump distance 323pt.
/// Gap rule (Sky Runner GETTING_STARTED.md §3): the gap under a floating
/// platform must be >= hero height (80) + tile margin (12) = 92pt.
final class LevelDataTests: XCTestCase {

    private let gravity: CGFloat = 1470
    private let jumpVelocity: CGFloat = 660
    private let moveSpeed: CGFloat = 360
    private let heroWidth: CGFloat = 30
    private let heroHeight: CGFloat = 80
    private let minGap: CGFloat = 92

    private var jumpHeight: CGFloat {
        jumpVelocity * jumpVelocity / (2 * gravity)
    }

    private typealias Stand = (x0: CGFloat, x1: CGFloat, top: CGFloat)

    private func stands(of level: LevelData) -> [Stand] {
        level.platforms.map { ($0.minX, $0.maxX, $0.maxY) }
    }

    /// Time airborne for a jump landing `rise` pt above takeoff.
    private func airtime(rise: CGFloat) -> CGFloat? {
        let disc = jumpVelocity * jumpVelocity - 2 * gravity * rise
        guard disc >= 0 else { return nil }
        return (jumpVelocity + sqrt(disc)) / gravity
    }

    /// Can the hero jump from stand `from` to stand `to`?
    private func canJump(from: Stand, to: Stand) -> Bool {
        let rise = to.top - from.top
        guard rise <= jumpHeight - 2 else { return false }
        guard let t = airtime(rise: rise) else { return false }
        let reach = moveSpeed * t
        let cx0 = from.x0 + heroWidth / 2
        let cx1 = from.x1 - heroWidth / 2
        let lx0 = to.x0 + heroWidth / 2
        let lx1 = to.x1 - heroWidth / 2
        guard cx1 >= cx0, lx1 >= lx0 else { return false }
        let gap: CGFloat
        if lx1 < cx0 { gap = cx0 - lx1 }
        else if cx1 < lx0 { gap = lx0 - cx1 }
        else { gap = 0 }
        return gap <= reach
    }

    /// Stands reachable from the spawn (ground under x=120) by jumps.
    private func reachableStands(of level: LevelData) -> Set<Int> {
        let ss = stands(of: level)
        guard let start = ss.firstIndex(where: { $0.x0 <= 120 && 120 <= $0.x1 && $0.top == 80 }) else {
            return []
        }
        var seen: Set<Int> = [start]
        var frontier = [start]
        while let cur = frontier.popLast() {
            for (i, other) in ss.enumerated() where !seen.contains(i) {
                if canJump(from: ss[cur], to: other) {
                    seen.insert(i)
                    frontier.append(i)
                }
            }
        }
        return seen
    }

    /// Is a point inside the jump envelope of a reachable stand?
    private func pointReachable(_ point: CGPoint, stands ss: [Stand], seen: Set<Int>) -> Bool {
        for i in seen {
            let s = ss[i]
            if point.x >= s.x0 - 30 && point.x <= s.x1 + 30
                && abs(point.y - (s.top + heroHeight / 2)) <= 55 {
                return true
            }
            let rise = point.y - s.top
            guard rise <= jumpHeight + 30, let t = airtime(rise: min(rise, jumpHeight - 0.01)) else { continue }
            let reach = moveSpeed * t + 30
            if point.x >= s.x0 + heroWidth / 2 - reach && point.x <= s.x1 - heroWidth / 2 + reach {
                return true
            }
        }
        return false
    }

    // MARK: - Table

    func testLevelTableHasExactly40Levels() {
        let numbers = LevelData.all.map(\.number).sorted()
        XCTAssertEqual(numbers, Array(1...40), "Level numbers must be exactly 1...40")
        XCTAssertEqual(LevelData.all.count, 40)
    }

    func testEachLevelNumberResolves() {
        for n in 1...40 {
            XCTAssertNotNil(LevelData.level(n), "Level \(n) must resolve via LevelData.level(_:)")
        }
        XCTAssertNil(LevelData.level(0))
        XCTAssertNil(LevelData.level(41))
    }

    // MARK: - Gap rule

    func testGapUnderEveryFloatingPlatform() {
        for level in LevelData.all {
            for rect in level.platforms where rect.height <= 40 && rect.minY > 0 {
                var best: CGFloat?
                for other in level.platforms {
                    let top = other.maxY
                    guard top < rect.minY - 0.01 else { continue }
                    let overlap = min(rect.maxX, other.maxX) - max(rect.minX, other.minX)
                    guard overlap >= heroWidth else { continue }
                    if let current = best {
                        if top > current { best = top }
                    } else {
                        best = top
                    }
                }
                guard let surfaceTop = best else { continue }  // over a pit
                let gap = rect.minY - surfaceTop
                XCTAssertGreaterThanOrEqual(
                    gap, minGap,
                    "L\(level.number): gap \(gap)pt under platform x=\(rect.minX) is below the "
                    + "92pt rule (hero 80 + margin 12) — the hero cannot walk under it")
            }
        }
    }

    // MARK: - Reachability

    func testAllFloatingPlatformsReachable() {
        for level in LevelData.all {
            let ss = stands(of: level)
            let seen = reachableStands(of: level)
            for (i, s) in ss.enumerated() where s.top > 80 {
                XCTAssertTrue(
                    seen.contains(i),
                    "L\(level.number): platform x=\(s.x0)..\(s.x1) top=\(s.top) is unreachable "
                    + "with the real jump envelope")
            }
        }
    }

    func testGoalReachableOrBossPresent() {
        for level in LevelData.all {
            let ss = stands(of: level)
            let seen = reachableStands(of: level)
            if level.isBoss {
                XCTAssertTrue(
                    level.enemies.contains { $0.type == .boss },
                    "L\(level.number): boss level without a boss enemy")
            } else {
                let ok = seen.contains { i in
                    let s = ss[i]
                    return level.goal.x >= s.x0 - 30 && level.goal.x <= s.x1 + 30
                        && abs(s.top - level.goal.y) < 1
                }
                XCTAssertTrue(ok, "L\(level.number): goal at \(level.goal) is unreachable")
            }
        }
    }

    func testAllCollectiblesReachable() {
        for level in LevelData.all {
            let ss = stands(of: level)
            let seen = reachableStands(of: level)
            for coin in level.coins {
                XCTAssertTrue(
                    pointReachable(coin, stands: ss, seen: seen),
                    "L\(level.number): coin at \(coin) is unreachable")
            }
            for gem in level.gems {
                XCTAssertTrue(
                    pointReachable(gem.position, stands: ss, seen: seen),
                    "L\(level.number): \(gem.color) gem at \(gem.position) is unreachable")
            }
            for heart in level.hearts {
                XCTAssertTrue(
                    pointReachable(heart, stands: ss, seen: seen),
                    "L\(level.number): heart at \(heart) is unreachable")
            }
            if let chest = level.chest {
                XCTAssertTrue(
                    pointReachable(chest, stands: ss, seen: seen),
                    "L\(level.number): chest at \(chest) is unreachable")
            }
        }
    }

    func testNoDuplicatedGemPositions() {
        for level in LevelData.all {
            let points = level.gems.map { "\($0.position.x),\($0.position.y)" }
            XCTAssertEqual(
                points.count, Set(points).count,
                "L\(level.number): duplicated gem position (v1.1 defect)")
        }
    }

    func testGroundEnemiesStandOnSurfaces() {
        for level in LevelData.all {
            let ss = stands(of: level)
            for enemy in level.enemies where enemy.type != .bat {
                let ok = ss.contains { $0.top == enemy.position.y
                    && enemy.position.x >= $0.x0 && enemy.position.x <= $0.x1 }
                XCTAssertTrue(
                    ok,
                    "L\(level.number): \(enemy.type) enemy at \(enemy.position) stands on no surface")
            }
        }
    }
}
