import Foundation
import SwiftUI
import UIKit

/// Persistent game state: currency, progress, shop, heroes, settings.
/// Stored in UserDefaults only. Fully offline. No real purchases here.
final class GameStore: ObservableObject {
    // MARK: - Currency
    @Published var coins: Int = 0 { didSet { saveInt(coins, key: "ha.coins") } }
    @Published var gems: Int = 0 { didSet { saveInt(gems, key: "ha.gems") } }

    // MARK: - Progress
    /// level number -> stars earned (0...3)
    @Published var stars: [Int: Int] = [:] { didSet { saveStars() } }
    /// Highest unlocked level number (1...40).
    @Published var unlockedLevel: Int = 1 { didSet { saveInt(unlockedLevel, key: "ha.unlocked") } }

    // MARK: - Shop
    @Published var ownedItems: Set<String> = [] { didSet { saveOwned() } }
    @Published var equippedHero: String = "hero" { didSet { saveString(equippedHero, key: "ha.hero") } }

    // MARK: - Settings
    @Published var soundOn: Bool = true { didSet { saveBool(soundOn, key: "ha.sound") } }
    @Published var musicOn: Bool = true { didSet { saveBool(musicOn, key: "ha.music") } }

    /// Last daily-bonus claim, as a time interval since 1970 (0 = never).
    @Published var lastDailyBonus: TimeInterval = 0 { didSet { saveDouble(lastDailyBonus, key: "ha.daily") } }

    // MARK: - Derived stats (from owned shop items)
    var swordLevel: Int {
        var level = 0
        if ownedItems.contains("sword1") { level += 1 }
        if ownedItems.contains("sword2") { level += 1 }
        return level
    }

    var swordDamage: Int { 1 + swordLevel }

    var armorLevel: Int {
        var level = 0
        if ownedItems.contains("armor1") { level += 1 }
        if ownedItems.contains("armor2") { level += 1 }
        return level
    }

    /// Base hearts 3, +1 per armor level, max 5.
    var maxHearts: Int { min(3 + armorLevel, 5) }

    var hasDoubleJump: Bool { ownedItems.contains("doubleJump") }

    var dashLevel: Int { ownedItems.contains("dash1") ? 1 : 0 }

    /// Dash cooldown in seconds (1.2 base, 1.0 with the upgrade).
    var dashCooldown: TimeInterval { 1.2 - 0.2 * Double(dashLevel) }

    // MARK: - Shop catalog
    static let shopItems: [ShopItem] = [
        ShopItem(id: "sword1", name: "سيف حاد", detail: "ضرر السيف +1", costCoins: 300, costGems: 0, kind: .sword),
        ShopItem(id: "sword2", name: "سيف الأساطير", detail: "ضرر السيف +1 (يتطلب سيف حاد)", costCoins: 800, costGems: 0, kind: .sword),
        ShopItem(id: "armor1", name: "درع حديدي", detail: "قلب إضافي +1", costCoins: 400, costGems: 0, kind: .armor),
        ShopItem(id: "armor2", name: "درع التنين", detail: "قلب إضافي +1 (يتطلب درع حديدي)", costCoins: 1000, costGems: 0, kind: .armor),
        ShopItem(id: "doubleJump", name: "قفزة مزدوجة", detail: "اقفز مرة ثانية في الهواء", costCoins: 0, costGems: 25, kind: .ability),
        ShopItem(id: "dash1", name: "اندفاع سريع", detail: "المراوغة أسرع (وقت انتظار أقل)", costCoins: 500, costGems: 0, kind: .ability),
    ]

    static let heroSkins: [HeroSkin] = [
        HeroSkin(id: "hero", name: "البطل الأخضر", tint: "green", costGems: 0),
        HeroSkin(id: "heroRed", name: "البطل القرمزي", tint: "red", costGems: 15),
        HeroSkin(id: "heroBlue", name: "البطل الأزرق", tint: "blue", costGems: 15),
        HeroSkin(id: "heroGold", name: "البطل الذهبي", tint: "gold", costGems: 30),
    ]

    /// SwiftUI tint color for a hero skin id.
    static func tintColor(for heroId: String) -> Color {
        Color(uiColor: tintUIColor(for: heroId))
    }

    /// UIKit tint color for a hero skin id (SpriteKit nodes need UIColor).
    static func tintUIColor(for heroId: String) -> UIColor {
        switch heroId {
        case "heroRed": return UIColor(red: 0.95, green: 0.45, blue: 0.45, alpha: 1)
        case "heroBlue": return UIColor(red: 0.45, green: 0.65, blue: 1.0, alpha: 1)
        case "heroGold": return UIColor(red: 1.0, green: 0.85, blue: 0.35, alpha: 1)
        default: return UIColor(red: 0.55, green: 0.95, blue: 0.55, alpha: 1)
        }
    }

    // MARK: - Init / persistence
    init() {
        let d = UserDefaults.standard
        coins = d.integer(forKey: "ha.coins")
        gems = d.integer(forKey: "ha.gems")
        unlockedLevel = max(1, min(40, d.integer(forKey: "ha.unlocked") == 0 ? 1 : d.integer(forKey: "ha.unlocked")))
        if let data = d.data(forKey: "ha.stars"),
           let decoded = try? JSONDecoder().decode([String: Int].self, from: data) {
            var out: [Int: Int] = [:]
            for (k, v) in decoded {
                if let n = Int(k) { out[n] = v }
            }
            stars = out
        }
        if let arr = d.array(forKey: "ha.owned") as? [String] {
            ownedItems = Set(arr)
        }
        let hero = d.string(forKey: "ha.hero") ?? "hero"
        equippedHero = Self.heroSkins.contains { $0.id == hero } ? hero : "hero"
        soundOn = d.object(forKey: "ha.sound") == nil ? true : d.bool(forKey: "ha.sound")
        musicOn = d.object(forKey: "ha.music") == nil ? true : d.bool(forKey: "ha.music")
        lastDailyBonus = d.double(forKey: "ha.daily")
    }

    private func saveInt(_ v: Int, key: String) { UserDefaults.standard.set(v, forKey: key) }
    private func saveBool(_ v: Bool, key: String) { UserDefaults.standard.set(v, forKey: key) }
    private func saveDouble(_ v: Double, key: String) { UserDefaults.standard.set(v, forKey: key) }
    private func saveString(_ v: String, key: String) { UserDefaults.standard.set(v, forKey: key) }

    private func saveStars() {
        var dict: [String: Int] = [:]
        for (k, v) in stars { dict[String(k)] = v }
        if let data = try? JSONEncoder().encode(dict) {
            UserDefaults.standard.set(data, forKey: "ha.stars")
        }
    }

    private func saveOwned() {
        UserDefaults.standard.set(Array(ownedItems), forKey: "ha.owned")
    }

    // MARK: - Currency
    func addCoins(_ n: Int) { coins += n }
    func addGems(_ n: Int) { gems += n }

    // MARK: - Level completion
    func completeLevel(number: Int, stars earned: Int, coins: Int, gems: Int) {
        let prev = self.stars[number] ?? 0
        self.stars[number] = max(prev, earned)
        if number < 40 && number >= unlockedLevel {
            unlockedLevel = number + 1
        }
        addCoins(coins)
        addGems(gems)
    }

    func stars(for level: Int) -> Int { stars[level] ?? 0 }

    var totalStars: Int { stars.values.reduce(0, +) }

    // MARK: - Daily bonus
    var canClaimDailyBonus: Bool {
        if lastDailyBonus <= 0 { return true }
        return Date().timeIntervalSince1970 - lastDailyBonus >= 24 * 3600
    }

    /// Daily bonus: +100 coins and +10 gems. Returns false if not claimable yet.
    @discardableResult
    func claimDailyBonus() -> Bool {
        guard canClaimDailyBonus else { return false }
        lastDailyBonus = Date().timeIntervalSince1970
        addCoins(100)
        addGems(10)
        return true
    }

    // MARK: - Shop
    func canBuy(_ item: ShopItem) -> Bool {
        if ownedItems.contains(item.id) { return false }
        if item.id == "sword2" && !ownedItems.contains("sword1") { return false }
        if item.id == "armor2" && !ownedItems.contains("armor1") { return false }
        return coins >= item.costCoins && gems >= item.costGems
    }

    @discardableResult
    func buy(_ item: ShopItem) -> Bool {
        guard canBuy(item) else { return false }
        coins -= item.costCoins
        gems -= item.costGems
        ownedItems.insert(item.id)
        return true
    }

    func buyHero(_ skin: HeroSkin) -> Bool {
        if skin.costGems == 0 {
            equippedHero = skin.id
            return true
        }
        if gems < skin.costGems { return false }
        gems -= skin.costGems
        equippedHero = skin.id
        return true
    }

    // MARK: - Reset
    func resetProgress() {
        coins = 0
        gems = 0
        stars = [:]
        unlockedLevel = 1
        ownedItems = []
        equippedHero = "hero"
        lastDailyBonus = 0
    }
}

struct ShopItem: Identifiable {
    let id: String
    let name: String
    let detail: String
    let costCoins: Int
    let costGems: Int
    let kind: Kind

    enum Kind { case sword, armor, ability }
}

struct HeroSkin: Identifiable {
    let id: String
    let name: String
    let tint: String
    let costGems: Int
}
