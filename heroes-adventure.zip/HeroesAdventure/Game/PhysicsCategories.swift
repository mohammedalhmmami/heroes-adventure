import Foundation

/// Physics categories for the whole game — one file, one source of truth.
///
/// Pattern: AngryBirds-iOS `PhysicsCategories.swift` (read in
/// GITHUB_DEEP_REVIEW.md §1.7 / MASTER_PROMPT_REPORT.md §5 row 9) —
/// single-bit categories in a single file, used by all three masks
/// (`categoryBitMask`, `collisionBitMask`, `contactTestBitMask`) with no
/// magic numbers anywhere else. Re-implemented in our own style; no code
/// copied (AngryBirds-iOS has no proven licence).
///
/// The three masks mean different things (SpriteKit docs, via the
/// GITHUB_DEEP_REVIEW frame-cycle notes):
/// - `categoryBitMask` — what this body IS.
/// - `collisionBitMask` — what the physics engine pushes it away from.
/// - `contactTestBitMask` — what triggers `didBegin(_:)` callbacks.
/// Mixing them up is the classic SpriteKit collision bug, so every body
/// in the game sets all three explicitly from these constants.
enum PhysicsCategory {
    /// The hero. Collides with platforms only; contacts enemies,
    /// collectibles, the goal and projectiles.
    static let hero: UInt32 = 0x1
    /// Solid ground and floating platforms. Collide with the hero only.
    static let platform: UInt32 = 0x2
    /// Enemies (slime, bat, spiky, skeleton, spider, boss). Kinematic
    /// bodies: they never push anything, they only report contact with
    /// the hero (`collisionBitMask = .none`).
    static let enemy: UInt32 = 0x4
    /// Coins, gems, hearts, chests. Sensor bodies: contact only.
    static let collectible: UInt32 = 0x8
    /// The level-end flag. Sensor body: contact only.
    static let goal: UInt32 = 0x10
    /// Boss thrown rocks. Sensor bodies: contact with hero and platforms.
    static let projectile: UInt32 = 0x20

    /// No collision with anything (sensor / kinematic bodies).
    static let none: UInt32 = 0
}
