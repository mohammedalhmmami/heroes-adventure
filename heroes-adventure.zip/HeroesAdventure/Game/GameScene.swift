import Foundation
import SpriteKit
import SwiftUI

// MARK: - Shared gameplay state

/// Touch input written by the SwiftUI control overlay, read by the scene.
final class GameInput: ObservableObject {
    var moveLeft = false
    var moveRight = false
    var jumpPressed = false
    var attackPressed = false
    var dodgePressed = false

    func pressJump() { jumpPressed = true }
    func pressAttack() { attackPressed = true }
    func pressDodge() { dodgePressed = true }
}

/// HUD values published to the SwiftUI overlay.
final class GameHUDState: ObservableObject {
    @Published var hearts: Int = 3
    @Published var maxHearts: Int = 3
    @Published var coins: Int = 0
    @Published var gems: Int = 0
    @Published var elapsed: TimeInterval = 0
    @Published var bossHealth: CGFloat?
    @Published var bossActive: Bool = false
    @Published var levelName: String = ""
}

enum GamePhase {
    case playing
    case paused
    case complete
    case gameOver
}

final class GameCoordinator: ObservableObject {
    @Published var phase: GamePhase = .playing
    @Published var result: GameResult?
}

struct GameResult {
    let level: Int
    let stars: Int
    let coins: Int
    let gems: Int
    let timeTaken: TimeInterval
    let damageTaken: Bool
}

// MARK: - Physics categories

enum PhysicsCategory {
    static let hero: UInt32 = 0x1
    static let platform: UInt32 = 0x2
    static let enemy: UInt32 = 0x4
    static let collectible: UInt32 = 0x8
    static let goal: UInt32 = 0x10
    static let projectile: UInt32 = 0x20
}

// MARK: - World theme

struct WorldTheme {
    let sky: SKColor
    let backgroundTint: SKColor
    let backgroundBlend: CGFloat
    let groundTile: String
    let platformFill: SKColor
    let platformTop: SKColor
    let dirtFill: SKColor

    static func forWorld(_ world: Int) -> WorldTheme {
        switch world {
        case 2:
            return WorldTheme(
                sky: SKColor(red: 0.95, green: 0.83, blue: 0.57, alpha: 1),
                backgroundTint: SKColor(red: 0.95, green: 0.80, blue: 0.45, alpha: 1),
                backgroundBlend: 0.30,
                groundTile: "tileDirt",
                platformFill: SKColor(red: 0.72, green: 0.54, blue: 0.29, alpha: 1),
                platformTop: SKColor(red: 0.91, green: 0.78, blue: 0.48, alpha: 1),
                dirtFill: SKColor(red: 0.54, green: 0.39, blue: 0.20, alpha: 1))
        case 3:
            return WorldTheme(
                sky: SKColor(red: 0.75, green: 0.89, blue: 0.95, alpha: 1),
                backgroundTint: SKColor(red: 0.65, green: 0.85, blue: 1.0, alpha: 1),
                backgroundBlend: 0.30,
                groundTile: "tileStone",
                platformFill: SKColor(red: 0.50, green: 0.66, blue: 0.79, alpha: 1),
                platformTop: SKColor(red: 0.87, green: 0.95, blue: 0.98, alpha: 1),
                dirtFill: SKColor(red: 0.35, green: 0.48, blue: 0.60, alpha: 1))
        case 4:
            return WorldTheme(
                sky: SKColor(red: 0.23, green: 0.16, blue: 0.16, alpha: 1),
                backgroundTint: SKColor(red: 0.75, green: 0.25, blue: 0.15, alpha: 1),
                backgroundBlend: 0.35,
                groundTile: "tileStone",
                platformFill: SKColor(red: 0.35, green: 0.23, blue: 0.23, alpha: 1),
                platformTop: SKColor(red: 0.54, green: 0.29, blue: 0.23, alpha: 1),
                dirtFill: SKColor(red: 0.18, green: 0.12, blue: 0.12, alpha: 1))
        default:
            return WorldTheme(
                sky: SKColor(red: 0.47, green: 0.71, blue: 0.84, alpha: 1),
                backgroundTint: .clear,
                backgroundBlend: 0,
                groundTile: "tileGrass",
                platformFill: SKColor(red: 0.42, green: 0.29, blue: 0.17, alpha: 1),
                platformTop: SKColor(red: 0.31, green: 0.60, blue: 0.24, alpha: 1),
                dirtFill: SKColor(red: 0.29, green: 0.20, blue: 0.13, alpha: 1))
        }
    }
}

// MARK: - Enemy node

final class EnemyNode: SKSpriteNode {
    let type: EnemyType
    var hp: Int
    let maxHp: Int
    let speed: CGFloat
    let patrolMin: CGFloat
    let patrolMax: CGFloat
    var direction: CGFloat = 1
    let baseY: CGFloat
    var phase: CGFloat = 0
    var isBoss: Bool { type == .boss }

    // Boss-only state
    var leapTimer: TimeInterval = 3
    var leapT: TimeInterval = -1
    var leapFrom: CGPoint = .zero
    var leapTo: CGPoint = .zero
    var rockTimer: TimeInterval = 4

    init(spawn: EnemySpawn, texture: SKTexture, size: CGSize) {
        self.type = spawn.type
        self.hp = spawn.hp
        self.maxHp = spawn.hp
        self.speed = spawn.speed
        self.patrolMin = spawn.patrolMin
        self.patrolMax = spawn.patrolMax
        self.baseY = spawn.position.y
        super.init(texture: texture, color: .clear, size: size)
        self.position = spawn.position
        self.name = "enemy"
        // Inset hitbox: 80% of visual width, 85% of visual height.
        let body = SKPhysicsBody(rectangleOf: CGSize(width: size.width * 0.8, height: size.height * 0.85))
        body.isDynamic = false
        body.categoryBitMask = PhysicsCategory.enemy
        body.collisionBitMask = 0
        body.contactTestBitMask = PhysicsCategory.hero
        self.physicsBody = body
    }

    required init?(coder aDecoder: NSCoder) { return nil }

    /// Per-frame movement. Returns nothing; the scene reads boss leap/rock state.
    func step(dt: CGFloat, time: TimeInterval, heroX: CGFloat) {
        phase += dt
        switch type {
        case .slime:
            // Hop: horizontal patrol + sine hop.
            position.x += direction * speed * dt
            position.y = baseY + abs(sin(phase * 4)) * 30
            bounceAtPatrolEdges()
        case .bat:
            // Fly: horizontal patrol + gentle vertical sine.
            position.x += direction * speed * dt
            position.y = baseY + sin(phase * 2) * 40
            bounceAtPatrolEdges()
        case .spiky, .skeleton, .spider:
            position.x += direction * speed * dt
            bounceAtPatrolEdges()
        case .boss:
            stepBoss(dt: dt, heroX: heroX)
        }
        // Face movement direction.
        if direction != 0 {
            xScale = abs(xScale) * direction
        }
    }

    private func bounceAtPatrolEdges() {
        if position.x <= patrolMin {
            position.x = patrolMin
            direction = 1
        } else if position.x >= patrolMax {
            position.x = patrolMax
            direction = -1
        }
    }

    private func stepBoss(dt: CGFloat, heroX: CGFloat) {
        if leapT >= 0 {
            // Mid-leap: parabolic arc toward the hero.
            leapT += TimeInterval(dt)
            let duration: TimeInterval = 0.7
            let t = min(leapT / duration, 1)
            let x = leapFrom.x + (leapTo.x - leapFrom.x) * CGFloat(t)
            let arc = sin(CGFloat(t) * .pi) * 130
            position = CGPoint(x: x, y: baseY + arc)
            if t >= 1 {
                leapT = -1
                position.y = baseY
            }
            return
        }
        // Walk toward the hero slowly, inside the patrol range.
        let dx = heroX - position.x
        if abs(dx) > 30 {
            direction = dx > 0 ? 1 : -1
            position.x += direction * speed * dt
            position.x = max(patrolMin, min(patrolMax, position.x))
        }
        leapTimer -= TimeInterval(dt)
        if leapTimer <= 0 && abs(dx) < 450 && abs(dx) > 120 {
            leapTimer = 3
            leapT = 0
            leapFrom = position
            leapTo = CGPoint(x: max(patrolMin, min(patrolMax, heroX)), y: baseY)
        }
    }

    func flash() {
        let original = colorBlendFactor
        color = .red
        colorBlendFactor = 0.6
        let wait = SKAction.wait(forDuration: 0.12)
        let restore = SKAction.run { [weak self] in
            self?.colorBlendFactor = original
        }
        run(SKAction.sequence([wait, restore]))
    }
}

// MARK: - Rock projectile (boss)

final class RockNode: SKShapeNode {
    var velocityX: CGFloat = 0
    var life: TimeInterval = 5

    init(position: CGPoint, direction: CGFloat) {
        super.init()
        self.path = CGPath(ellipseIn: CGRect(x: -12, y: -12, width: 24, height: 24), transform: nil)
        self.fillColor = SKColor(red: 0.35, green: 0.32, blue: 0.30, alpha: 1)
        self.strokeColor = .black
        self.lineWidth = 2
        self.position = position
        self.name = "rock"
        self.velocityX = direction * 300
        let body = SKPhysicsBody(circleOfRadius: 12)
        body.isDynamic = false
        body.categoryBitMask = PhysicsCategory.projectile
        body.collisionBitMask = 0
        body.contactTestBitMask = PhysicsCategory.hero | PhysicsCategory.platform
        self.physicsBody = body
    }

    required init?(coder aDecoder: NSCoder) { return nil }
}

// MARK: - Game scene

final class GameScene: SKScene, SKPhysicsContactDelegate {
    // Tuning (locked): gravity -1470 pt/s^2, jump 660 -> 148pt jump height,
    // move 330 -> 297pt jump distance, coyote 0.12s, jump buffer 0.12s.
    private static let gravity: CGFloat = -1470
    private static let jumpVelocity: CGFloat = 660
    private static let moveSpeed: CGFloat = 330
    private static let maxFallSpeed: CGFloat = -1400
    private static let coyoteTime: TimeInterval = 0.12
    private static let jumpBufferTime: TimeInterval = 0.12
    private static let attackRange: CGFloat = 90
    private static let attackCooldown: TimeInterval = 0.35
    private static let dodgeDuration: TimeInterval = 0.25
    private static let dodgeSpeed: CGFloat = 620
    private static let invulnerableTime: TimeInterval = 1.0
    private static let heroHitbox = CGSize(width: 34, height: 88)
    private static let heroVisualHeight: CGFloat = 96

    private let level: LevelData
    private let store: GameStore
    private let input: GameInput
    private let hud: GameHUDState
    private let coordinator: GameCoordinator
    private let theme: WorldTheme

    private var hero: SKSpriteNode?
    private var cameraNode: SKCameraNode?
    private var worldNode = SKNode()
    private var backgroundNode = SKNode()
    private var enemies: [EnemyNode] = []
    private var rocks: [RockNode] = []
    private var boss: EnemyNode?

    private var time: TimeInterval = 0
    private var lastUpdate: TimeInterval = 0
    private var elapsed: TimeInterval = 0
    private var lastGroundedTime: TimeInterval = -10
    private var lastJumpPressTime: TimeInterval = -10
    private var jumpsUsed = 0
    private var facing: CGFloat = 1
    private var hearts: Int = 3
    private var coinsCollected = 0
    private var totalCoins = 0
    private var gemsCollected = 0
    private var chestOpened = false
    private var kills = 0
    private var damageTaken = false
    private var invulnerableUntil: TimeInterval = 0
    private var attackReadyAt: TimeInterval = 0
    private var dodgeReadyAt: TimeInterval = 0
    private var dodgeUntil: TimeInterval = 0
    private var dodgeDirection: CGFloat = 1
    private var spawnPoint = CGPoint(x: 120, y: 120)
    private var finished = false
    private var finishTimer: TimeInterval = -1
    private var pendingResult: GameResult?
    private var pendingGameOver = false

    init(level: LevelData, store: GameStore, input: GameInput, hud: GameHUDState, coordinator: GameCoordinator) {
        self.level = level
        self.store = store
        self.input = input
        self.hud = hud
        self.coordinator = coordinator
        self.theme = WorldTheme.forWorld(level.world)
        super.init(size: CGSize(width: 1280, height: 720))
        scaleMode = .aspectFit
        backgroundColor = theme.sky
        physicsWorld.gravity = CGVector(dx: 0, dy: Self.gravity)
        physicsWorld.contactDelegate = self
    }

    required init?(coder aDecoder: NSCoder) { return nil }

    // MARK: - Build

    override func didMove(to view: SKView) {
        hearts = store.maxHearts
        hud.maxHearts = store.maxHearts
        hud.hearts = hearts
        hud.coins = 0
        hud.gems = 0
        hud.elapsed = 0
        hud.bossActive = level.isBoss
        hud.bossHealth = level.isBoss ? 1 : nil
        hud.levelName = "المستوى \(level.number) — \(level.worldName)"
        totalCoins = level.coins.count

        buildBackground()
        addChild(worldNode)
        buildPlatforms()
        buildCollectibles()
        buildEnemies()
        buildGoal()
        buildHero()
        buildCamera()
    }

    private func buildBackground() {
        // Tiled forest panorama with parallax (moves at 0.5x camera speed).
        let texture = SKTexture(imageNamed: "backgroundForest")
        let tileWidth: CGFloat = 2160
        let tileHeight: CGFloat = 720
        var x: CGFloat = -640
        while x < level.width + 640 {
            let sprite = SKSpriteNode(texture: texture)
            sprite.size = CGSize(width: tileWidth, height: tileHeight)
            sprite.position = CGPoint(x: x + tileWidth / 2, y: 360)
            sprite.zPosition = -10
            if theme.backgroundBlend > 0 {
                sprite.color = theme.backgroundTint
                sprite.colorBlendFactor = theme.backgroundBlend
            }
            backgroundNode.addChild(sprite)
            x += tileWidth
        }
        addChild(backgroundNode)
    }

    private func buildPlatforms() {
        let tileTexture = SKTexture(imageNamed: theme.groundTile)
        for rect in level.platforms {
            // Physics: solid, hero collides, no contact events needed.
            let node = SKSpriteNode(color: .clear, size: rect.size)
            node.position = CGPoint(x: rect.midX, y: rect.midY)
            node.zPosition = 1
            let body = SKPhysicsBody(rectangleOf: rect.size)
            body.isDynamic = false
            body.categoryBitMask = PhysicsCategory.platform
            body.collisionBitMask = PhysicsCategory.hero
            body.contactTestBitMask = 0
            node.physicsBody = body
            worldNode.addChild(node)

            if rect.height > 40 {
                // Ground: tile row on top + dark fill below.
                let tileSize: CGFloat = 56
                var tx = rect.minX + tileSize / 2
                while tx < rect.maxX {
                    let tile = SKSpriteNode(texture: tileTexture)
                    let w = min(tileSize, rect.maxX - (tx - tileSize / 2))
                    tile.size = CGSize(width: w, height: 48)
                    tile.position = CGPoint(x: tx + (w - tileSize) / 2, y: rect.maxY - 24)
                    tile.zPosition = 2
                    if theme.backgroundBlend > 0 && theme.groundTile == "tileStone" {
                        tile.color = theme.backgroundTint
                        tile.colorBlendFactor = 0.25
                    }
                    worldNode.addChild(tile)
                    tx += tileSize
                }
                let fill = SKSpriteNode(color: theme.dirtFill, size: CGSize(width: rect.width, height: 32))
                fill.position = CGPoint(x: rect.midX, y: rect.minY + 16)
                fill.zPosition = 1
                worldNode.addChild(fill)
            } else {
                // Floating platform: rounded body + bright top strip.
                let bodyShape = SKShapeNode(rect: CGRect(x: -rect.width / 2, y: -rect.height / 2, width: rect.width, height: rect.height), cornerRadius: 6)
                bodyShape.fillColor = theme.platformFill
                bodyShape.strokeColor = .clear
                bodyShape.position = CGPoint(x: rect.midX, y: rect.midY)
                bodyShape.zPosition = 2
                worldNode.addChild(bodyShape)
                let top = SKSpriteNode(color: theme.platformTop, size: CGSize(width: rect.width - 4, height: 7))
                top.position = CGPoint(x: rect.midX, y: rect.maxY - 4)
                top.zPosition = 3
                worldNode.addChild(top)
            }
        }
    }

    private func collectibleBody(radius: CGFloat) -> SKPhysicsBody {
        let body = SKPhysicsBody(circleOfRadius: radius)
        body.isDynamic = false
        body.categoryBitMask = PhysicsCategory.collectible
        body.collisionBitMask = 0
        body.contactTestBitMask = PhysicsCategory.hero
        return body
    }

    private func buildCollectibles() {
        for (i, p) in level.coins.enumerated() {
            let coin = SKSpriteNode(imageNamed: "coin")
            coin.size = CGSize(width: 30, height: 29)
            coin.position = p
            coin.zPosition = 5
            coin.name = "coin_\(i)"
            coin.physicsBody = collectibleBody(radius: 13)
            coin.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.moveBy(x: 0, y: 6, duration: 0.5),
                SKAction.moveBy(x: 0, y: -6, duration: 0.5),
            ])))
            worldNode.addChild(coin)
        }
        for (i, g) in level.gems.enumerated() {
            let name: String
            switch g.color {
            case .blue: name = "gemBlue"
            case .red: name = "gemRed"
            case .green: name = "gemGreen"
            }
            let gem = SKSpriteNode(imageNamed: name)
            gem.size = CGSize(width: 30, height: 28)
            gem.position = g.position
            gem.zPosition = 5
            gem.name = "gem_\(i)"
            gem.userData = NSMutableDictionary()
            gem.userData?["value"] = g.color.value
            gem.physicsBody = collectibleBody(radius: 14)
            gem.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.scaleX(to: 0.4, duration: 0.4),
                SKAction.scaleX(to: 1.0, duration: 0.4),
            ])))
            worldNode.addChild(gem)
        }
        for (i, p) in level.hearts.enumerated() {
            let heart = SKSpriteNode(imageNamed: "heart")
            heart.size = CGSize(width: 32, height: 27)
            heart.position = p
            heart.zPosition = 5
            heart.name = "heart_\(i)"
            heart.physicsBody = collectibleBody(radius: 14)
            heart.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.scale(to: 1.15, duration: 0.5),
                SKAction.scale(to: 1.0, duration: 0.5),
            ])))
            worldNode.addChild(heart)
        }
        if let chestPos = level.chest {
            let chest = SKSpriteNode(imageNamed: "chest")
            chest.size = CGSize(width: 66, height: 56)
            chest.position = chestPos
            chest.zPosition = 5
            chest.name = "chest"
            chest.physicsBody = collectibleBody(radius: 26)
            worldNode.addChild(chest)
        }
    }

    private func enemyTexture(for type: EnemyType) -> (name: String, height: CGFloat) {
        switch type {
        case .spiky: return ("enemySpiky", 72)
        case .bat: return ("enemyBat", 56)
        case .slime: return ("enemySlime", 64)
        case .skeleton: return ("enemySkeleton", 88)
        case .spider: return ("enemySpider", 64)
        case .boss: return ("bossGolem", 150)
        }
    }

    private func buildEnemies() {
        for spawn in level.enemies {
            let (textureName, height) = enemyTexture(for: spawn.type)
            let texture = SKTexture(imageNamed: textureName)
            let scale = height / texture.size().height
            let size = CGSize(width: texture.size().width * scale, height: height)
            let enemy = EnemyNode(spawn: spawn, texture: texture, size: size)
            // Ground types stand on the surface: center = surface + half height.
            // Flying bat uses its spawn position as its center.
            if spawn.type != .bat {
                enemy.position = CGPoint(x: spawn.position.x, y: spawn.position.y + height / 2)
            }
            enemy.zPosition = 6
            if spawn.type == .boss {
                boss = enemy
                if level.world == 2 {
                    enemy.color = SKColor(red: 0.85, green: 0.70, blue: 0.45, alpha: 1)
                    enemy.colorBlendFactor = 0.4
                } else if level.world == 3 {
                    enemy.color = SKColor(red: 0.65, green: 0.85, blue: 1.0, alpha: 1)
                    enemy.colorBlendFactor = 0.4
                } else if level.world == 4 {
                    enemy.color = SKColor(red: 0.90, green: 0.35, blue: 0.25, alpha: 1)
                    enemy.colorBlendFactor = 0.45
                }
            }
            enemies.append(enemy)
            worldNode.addChild(enemy)
        }
    }

    private func buildGoal() {
        guard !level.isBoss else { return }
        let flag = SKNode()
        flag.position = CGPoint(x: level.goal.x, y: level.goal.y)
        flag.zPosition = 5
        flag.name = "goal"
        let pole = SKShapeNode(rect: CGRect(x: -3, y: 0, width: 6, height: 120), cornerRadius: 2)
        pole.fillColor = SKColor(red: 0.45, green: 0.30, blue: 0.15, alpha: 1)
        pole.strokeColor = .clear
        flag.addChild(pole)
        let cloth = SKShapeNode(rect: CGRect(x: 3, y: 82, width: 56, height: 34), cornerRadius: 4)
        cloth.fillColor = SKColor(red: 0.20, green: 0.75, blue: 0.35, alpha: 1)
        cloth.strokeColor = .clear
        flag.addChild(cloth)
        let body = SKPhysicsBody(rectangleOf: CGSize(width: 60, height: 120), center: CGPoint(x: 20, y: 60))
        body.isDynamic = false
        body.categoryBitMask = PhysicsCategory.goal
        body.collisionBitMask = 0
        body.contactTestBitMask = PhysicsCategory.hero
        flag.physicsBody = body
        flag.run(SKAction.repeatForever(SKAction.sequence([
            SKAction.scaleX(to: 0.85, duration: 0.4),
            SKAction.scaleX(to: 1.0, duration: 0.4),
        ])))
        worldNode.addChild(flag)
    }

    private func buildHero() {
        let texture = SKTexture(imageNamed: "hero")
        let scale = Self.heroVisualHeight / texture.size().height
        let size = CGSize(width: texture.size().width * scale, height: Self.heroVisualHeight)
        let heroNode = SKSpriteNode(texture: texture, size: size)
        heroNode.position = spawnPoint
        heroNode.zPosition = 10
        heroNode.name = "hero"
        heroNode.color = GameStore.tintUIColor(for: store.equippedHero)
        heroNode.colorBlendFactor = 0.35
        let body = SKPhysicsBody(rectangleOf: Self.heroHitbox)
        body.isDynamic = true
        body.allowsRotation = false
        body.categoryBitMask = PhysicsCategory.hero
        body.collisionBitMask = PhysicsCategory.platform
        body.contactTestBitMask = PhysicsCategory.enemy | PhysicsCategory.collectible | PhysicsCategory.goal | PhysicsCategory.projectile
        body.usesPreciseCollisionDetection = true
        heroNode.physicsBody = body
        hero = heroNode
        worldNode.addChild(heroNode)
    }

    private func buildCamera() {
        let cam = SKCameraNode()
        cam.position = CGPoint(x: 640, y: 360)
        camera = cam
        cameraNode = cam
        addChild(cam)
    }

    // MARK: - Update

    override func update(_ currentTime: TimeInterval) {
        if lastUpdate == 0 { lastUpdate = currentTime }
        let dt = min(currentTime - lastUpdate, 1.0 / 30.0)
        lastUpdate = currentTime
        time += dt
        if finished {
            tickFinish(dt: dt)
            return
        }
        elapsed += dt
        hud.elapsed = elapsed

        guard let hero = hero, let body = hero.physicsBody else { return }

        consumeInput()
        updateHeroMovement(hero: hero, body: body, dt: CGFloat(dt))
        updateEnemies(dt: CGFloat(dt))
        updateRocks(dt: CGFloat(dt))
        updateCamera(hero: hero)
        checkPitFall(hero: hero)
    }

    private func consumeInput() {
        if input.jumpPressed {
            input.jumpPressed = false
            lastJumpPressTime = time
        }
        if input.attackPressed {
            input.attackPressed = false
            tryAttack()
        }
        if input.dodgePressed {
            input.dodgePressed = false
            tryDodge()
        }
    }

    private var isGrounded: Bool {
        time - lastGroundedTime <= Self.coyoteTime
    }

    private func updateHeroMovement(hero: SKSpriteNode, body: SKPhysicsBody, dt: CGFloat) {
        // Manual grounded check: hero bottom within 6pt of a platform top,
        // horizontally overlapping, and not moving up.
        let bottom = hero.position.y - Self.heroHitbox.height / 2
        var grounded = false
        if body.velocity.dy <= 1 {
            for rect in level.platforms {
                if bottom >= rect.maxY - 3 && bottom <= rect.maxY + 6
                    && hero.position.x + 14 > rect.minX
                    && hero.position.x - 14 < rect.maxX {
                    grounded = true
                    break
                }
            }
        }
        if grounded {
            lastGroundedTime = time
            jumpsUsed = 0
        }

        // Jump: buffered press + coyote time, or double jump.
        if time - lastJumpPressTime <= Self.jumpBufferTime {
            if isGrounded {
                body.velocity.dy = Self.jumpVelocity
                lastJumpPressTime = -10
                jumpsUsed = 1
                SoundManager.shared.jump()
            } else if store.hasDoubleJump && jumpsUsed == 1 {
                body.velocity.dy = Self.jumpVelocity
                lastJumpPressTime = -10
                jumpsUsed = 2
                SoundManager.shared.jump()
            }
        }

        // Horizontal movement (smooth toward target speed).
        var targetX: CGFloat = 0
        if input.moveLeft { targetX = -Self.moveSpeed; facing = -1 }
        if input.moveRight { targetX = Self.moveSpeed; facing = 1 }
        if time < dodgeUntil {
            targetX = dodgeDirection * Self.dodgeSpeed
        }
        let rate = 1 - exp(-20 * Double(dt))
        body.velocity.dx += (targetX - body.velocity.dx) * CGFloat(rate)
        hero.xScale = abs(hero.xScale) * facing

        // Cap fall speed.
        if body.velocity.dy < Self.maxFallSpeed {
            body.velocity.dy = Self.maxFallSpeed
        }
    }

    private func updateEnemies(dt: CGFloat) {
        guard let hero = hero else { return }
        for enemy in enemies {
            enemy.step(dt: dt, time: time, heroX: hero.position.x)
        }
        if let boss = boss {
            hud.bossHealth = CGFloat(boss.hp) / CGFloat(max(boss.maxHp, 1))
            boss.rockTimer -= TimeInterval(dt)
            if boss.rockTimer <= 0 && boss.leapT < 0 {
                boss.rockTimer = 4
                throwRock(from: boss)
            }
        }
    }

    private func throwRock(from boss: EnemyNode) {
        guard let hero = hero else { return }
        let dx = hero.position.x - boss.position.x
        guard abs(dx) < 520 else { return }
        let direction: CGFloat = dx > 0 ? 1 : -1
        let rock = RockNode(position: CGPoint(x: boss.position.x + direction * 80, y: boss.position.y + 40), direction: direction)
        rocks.append(rock)
        worldNode.addChild(rock)
    }

    private func updateRocks(dt: CGFloat) {
        for rock in rocks {
            rock.position.x += rock.velocityX * dt
            rock.life -= TimeInterval(dt)
            if rock.life <= 0 || rock.position.x < 0 || rock.position.x > level.width {
                rock.removeFromParent()
            }
        }
        rocks.removeAll { $0.parent == nil }
    }

    private func updateCamera(hero: SKSpriteNode) {
        guard let cam = cameraNode else { return }
        let minX: CGFloat = 640
        let maxX = max(minX, level.width - 640)
        let targetX = max(minX, min(maxX, hero.position.x))
        cam.position = CGPoint(x: targetX, y: 360)
        backgroundNode.position.x = targetX * 0.5 - 320
    }

    private func checkPitFall(hero: SKSpriteNode) {
        if hero.position.y < -120 {
            damageHero(fromX: hero.position.x - 100)
            hero.position = spawnPoint
            hero.physicsBody?.velocity = .zero
        }
    }

    // MARK: - Combat

    private func tryAttack() {
        guard time >= attackReadyAt, let hero = hero else { return }
        attackReadyAt = time + Self.attackCooldown
        // Slash visual in front of the hero.
        let slash = SKShapeNode()
        let path = CGMutablePath()
        path.addArc(center: .zero, radius: 70, startAngle: -0.7, endAngle: 0.7, clockwise: false)
        slash.path = path
        slash.strokeColor = .white
        slash.lineWidth = 7
        slash.position = CGPoint(x: hero.position.x + facing * 50, y: hero.position.y)
        slash.zPosition = 20
        addChild(slash)
        slash.run(SKAction.sequence([
            SKAction.fadeOut(withDuration: 0.15),
            SKAction.removeFromParent(),
        ]))
        // Hit every enemy in range in front of the hero (or very close).
        for enemy in enemies where enemy.parent != nil {
            let dx = enemy.position.x - hero.position.x
            let dy = enemy.position.y - hero.position.y
            let inFront = (dx * facing > 0) || abs(dx) < 30
            if inFront && abs(dx) <= Self.attackRange && abs(dy) <= 70 {
                damageEnemy(enemy, amount: store.swordDamage)
            }
        }
    }

    private func tryDodge() {
        guard time >= dodgeReadyAt else { return }
        dodgeReadyAt = time + store.dashCooldown
        dodgeUntil = time + Self.dodgeDuration
        dodgeDirection = facing
        invulnerableUntil = max(invulnerableUntil, time + Self.dodgeDuration)
    }

    private func damageEnemy(_ enemy: EnemyNode, amount: Int) {
        enemy.hp -= amount
        enemy.flash()
        if enemy.hp <= 0 {
            kills += 1
            syncHUDCurrency()
            SoundManager.shared.enemyDie()
            let dying = enemy
            enemies.removeAll { $0 === dying }
            if dying === boss { boss = nil }
            dying.physicsBody = nil
            dying.run(SKAction.sequence([
                SKAction.scale(to: 0, duration: 0.2),
                SKAction.removeFromParent(),
            ]))
            if dying.isBoss {
                completeLevel()
            }
        } else if enemy.isBoss {
            SoundManager.shared.bossHit()
        }
    }

    private func damageHero(fromX: CGFloat) {
        guard time >= invulnerableUntil, let hero = hero, let body = hero.physicsBody else { return }
        hearts -= 1
        hud.hearts = hearts
        damageTaken = true
        invulnerableUntil = time + Self.invulnerableTime
        SoundManager.shared.hurt()
        let away: CGFloat = hero.position.x >= fromX ? 1 : -1
        body.velocity = CGVector(dx: away * 300, dy: 220)
        // Blink while invulnerable.
        hero.removeAction(forKey: "blink")
        let blink = SKAction.repeat(
            SKAction.sequence([
                SKAction.fadeAlpha(to: 0.4, duration: 0.1),
                SKAction.fadeAlpha(to: 1.0, duration: 0.1),
            ]),
            count: 5)
        hero.run(blink, withKey: "blink")
        if hearts <= 0 {
            gameOver()
        }
    }

    // MARK: - Contacts

    func didBegin(_ contact: SKPhysicsContact) {
        let a = contact.bodyA
        let b = contact.bodyB
        let heroBody = (a.categoryBitMask == PhysicsCategory.hero) ? a : (b.categoryBitMask == PhysicsCategory.hero) ? b : nil
        let other = (heroBody === a) ? b : (heroBody === b) ? a : nil
        guard let other = other, let otherNode = other.node else { return }

        switch other.categoryBitMask {
        case PhysicsCategory.collectible:
            collect(node: otherNode)
        case PhysicsCategory.enemy:
            if let enemy = otherNode as? EnemyNode {
                damageHero(fromX: enemy.position.x)
            }
        case PhysicsCategory.goal:
            completeLevel()
        case PhysicsCategory.projectile:
            damageHero(fromX: otherNode.position.x)
            otherNode.removeFromParent()
        default:
            break
        }
    }

    /// HUD currency: coins from pickups + chest bonus + 2 per kill.
    private func syncHUDCurrency() {
        hud.coins = coinsCollected + (chestOpened ? 25 : 0) + kills * 2
        hud.gems = gemsCollected + (chestOpened ? 5 : 0)
    }

    private func collect(node: SKNode) {
        guard let name = node.name else { return }
        if name.hasPrefix("coin_") {
            coinsCollected += 1
            syncHUDCurrency()
            SoundManager.shared.coin()
            node.removeFromParent()
        } else if name.hasPrefix("gem_") {
            let value = (node.userData?["value"] as? Int) ?? 5
            gemsCollected += value
            syncHUDCurrency()
            SoundManager.shared.gem()
            node.removeFromParent()
        } else if name.hasPrefix("heart_") {
            if hearts < store.maxHearts {
                hearts += 1
                hud.hearts = hearts
            }
            SoundManager.shared.coin()
            node.removeFromParent()
        } else if name == "chest" {
            chestOpened = true
            syncHUDCurrency()
            SoundManager.shared.chest()
            node.removeFromParent()
        }
    }

    // MARK: - Finish

    private func starsEarned() -> Int {
        if coinsCollected >= totalCoins && !damageTaken && elapsed <= level.parTime {
            return 3
        }
        if totalCoins > 0 && coinsCollected * 10 >= totalCoins * 7 {
            return 2
        }
        return 1
    }

    private func completeLevel() {
        guard !finished else { return }
        finished = true
        let stars = starsEarned()
        let coins = coinsCollected + (chestOpened ? 25 : 0) + kills * 2
        let gems = gemsCollected + (chestOpened ? 5 : 0)
        pendingResult = GameResult(
            level: level.number,
            stars: stars,
            coins: coins,
            gems: gems,
            timeTaken: elapsed,
            damageTaken: damageTaken)
        finishTimer = 0.6
        SoundManager.shared.win()
        hero?.physicsBody?.velocity = .zero
    }

    private func gameOver() {
        guard !finished else { return }
        finished = true
        pendingGameOver = true
        finishTimer = 0.8
        SoundManager.shared.lose()
    }

    private func tickFinish(dt: TimeInterval) {
        guard finishTimer > 0 else { return }
        finishTimer -= dt
        if finishTimer <= 0 {
            isPaused = true
            if let result = pendingResult {
                coordinator.result = result
                coordinator.phase = .complete
            } else if pendingGameOver {
                coordinator.phase = .gameOver
            }
        }
    }
}
