import AVFoundation
import Foundation

/// Synthesized sound effects and a simple music loop.
/// No bundled audio files. Everything is generated tones, so the app
/// stays lightweight. All failures are silent (no sound rather than a crash).
final class SoundManager {
    static let shared = SoundManager()

    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private let format: AVAudioFormat?
    private var engineStarted = false
    private var musicTimer: DispatchSourceTimer?
    private var musicStep = 0
    private var musicOn = true
    private var soundOn = true

    /// A calm 16-step loop (C major pentatonic), one note per step.
    private let melody: [Double] = [
        523.25, 587.33, 659.25, 783.99,
        659.25, 587.33, 523.25, 392.00,
        523.25, 659.25, 783.99, 1046.50,
        783.99, 659.25, 587.33, 523.25,
    ]

    private init() {
        format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)
        if let format = format {
            engine.attach(player)
            engine.connect(player, to: engine.mainMixerNode, format: format)
        }
    }

    func configure(soundOn: Bool, musicOn: Bool) {
        self.soundOn = soundOn
        self.musicOn = musicOn
        if musicOn {
            startMusic()
        } else {
            stopMusic()
        }
    }

    // MARK: - Engine

    private func ensureEngine() -> Bool {
        guard let _ = format else { return false }
        if engineStarted { return true }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, options: [.mixWithOthers])
            try session.setActive(true)
            try engine.start()
            player.play()
            engineStarted = true
            return true
        } catch {
            return false
        }
    }

    /// Play a sine tone, optionally sweeping from freqStart to freqEnd.
    private func tone(freqStart: Double, freqEnd: Double, duration: Double, volume: Float) {
        guard soundOn else { return }
        guard ensureEngine(), let format = format else { return }
        let sampleRate = 44100.0
        let frames = Int(sampleRate * duration)
        guard frames > 0,
              let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(frames)) else { return }
        buffer.frameLength = AVAudioFrameCount(frames)
        guard let channel = buffer.floatChannelData?[0] else { return }
        for i in 0..<frames {
            let t = Double(i) / sampleRate
            let f = freqStart + (freqEnd - freqStart) * (Double(i) / Double(frames))
            // exponential decay envelope so the tone ends cleanly
            let env = exp(-3.0 * Double(i) / Double(frames))
            channel[i] = Float(sin(2.0 * Double.pi * f * t) * env) * volume
        }
        player.scheduleBuffer(buffer, at: nil, options: [], completionHandler: nil)
    }

    private func tone(freq: Double, duration: Double, volume: Float) {
        tone(freqStart: freq, freqEnd: freq, duration: duration, volume: volume)
    }

    // MARK: - Effects

    func click() { tone(freq: 800, duration: 0.06, volume: 0.25) }
    func jump() { tone(freqStart: 280, freqEnd: 620, duration: 0.14, volume: 0.3) }
    func coin() {
        tone(freq: 988, duration: 0.07, volume: 0.3)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.07) { [weak self] in
            self?.tone(freq: 1319, duration: 0.12, volume: 0.3)
        }
    }
    func gem() {
        tone(freq: 1175, duration: 0.08, volume: 0.3)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { [weak self] in
            self?.tone(freq: 1568, duration: 0.14, volume: 0.3)
        }
    }
    func hurt() { tone(freqStart: 220, freqEnd: 110, duration: 0.2, volume: 0.4) }
    func enemyDie() { tone(freqStart: 520, freqEnd: 180, duration: 0.18, volume: 0.3) }
    func chest() {
        for (i, f) in [523.25, 659.25, 783.99].enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.09) { [weak self] in
                self?.tone(freq: f, duration: 0.12, volume: 0.3)
            }
        }
    }
    func win() {
        for (i, f) in [523.25, 659.25, 783.99, 1046.50].enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.12) { [weak self] in
                self?.tone(freq: f, duration: 0.18, volume: 0.35)
            }
        }
    }
    func lose() {
        for (i, f) in [392.00, 329.63, 261.63].enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.15) { [weak self] in
                self?.tone(freq: f, duration: 0.2, volume: 0.3)
            }
        }
    }
    func bossHit() { tone(freqStart: 140, freqEnd: 70, duration: 0.25, volume: 0.45) }

    // MARK: - Music

    func startMusic() {
        guard musicOn else { return }
        stopMusic()
        musicStep = 0
        let timer = DispatchSource.makeTimerSource(queue: DispatchQueue.main)
        timer.schedule(deadline: .now(), repeating: 0.42)
        timer.setEventHandler { [weak self] in
            guard let self = self else { return }
            guard self.musicOn else { return }
            let f = self.melody[self.musicStep % self.melody.count]
            self.musicStep += 1
            self.tone(freq: f, duration: 0.4, volume: 0.08)
        }
        timer.resume()
        musicTimer = timer
    }

    func stopMusic() {
        musicTimer?.cancel()
        musicTimer = nil
    }
}
