import SpriteKit
import SwiftUI

struct GameView: View {
    @EnvironmentObject var store: GameStore
    let level: LevelData
    let onExit: () -> Void
    let onNextLevel: (Int) -> Void

    @StateObject private var input = GameInput()
    @StateObject private var hud = GameHUDState()
    @StateObject private var coordinator = GameCoordinator()
    @State private var scene: GameScene?
    @State private var recordedResult = false
    // Last scene size / safe area, reused when a level is restarted.
    @State private var lastSceneSize = CGSize(width: 1280, height: 720)
    @State private var lastSafeArea = EdgeInsets()

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let scene = scene {
                    SpriteView(scene: scene, options: [.ignoresSiblingOrder])
                        .ignoresSafeArea()
                } else {
                    GameBackground()
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                }

                // HUD (display only) while playing or paused.
                // The touch controls are drawn by the scene itself
                // (GameScene.buildControls) — the SwiftUI overlay sat above
                // the SpriteView and did not deliver touches reliably on
                // device (v1.0: buttons did nothing, hero never moved).
                // v1.2: this VStack's Spacer covered the whole screen above
                // the SpriteView, so the scene's touchesBegan never fired
                // at all (v1.1 video: timer runs, hero never moves). The HUD
                // is display-only, so allowsHitTesting(false) lets every
                // touch pass straight through to the scene's controls.
                if coordinator.phase == .playing || coordinator.phase == .paused {
                    VStack(spacing: 0) {
                        // Top HUD bar
                        HStack(spacing: 10) {
                            HStack(spacing: 2) {
                                ForEach(0..<hud.maxHearts, id: \.self) { i in
                                    Image(systemName: i < hud.hearts ? "heart.fill" : "heart")
                                        .font(.system(size: 20))
                                        .foregroundColor(i < hud.hearts ? .red : Color.white.opacity(0.4))
                                }
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.black.opacity(0.45))
                            .cornerRadius(20)

                            StatPill(imageName: "coin", value: "\(hud.coins)", isSystemImage: false)
                            StatPill(imageName: "gemBlue", value: "\(hud.gems)", isSystemImage: false)
                            Text(timeString(hud.elapsed))
                                .font(.system(size: 17, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.black.opacity(0.45))
                                .cornerRadius(20)

                            Spacer()

                            Text(hud.levelName)
                                .font(.system(size: 16, weight: .semibold, design: .rounded))
                                .foregroundColor(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.black.opacity(0.45))
                                .cornerRadius(20)

                            // Space reserved for the scene's pause button
                            // (top-left), so the level name never sits under it.
                            Color.clear.frame(width: 44, height: 44)
                        }
                        .padding(.leading, 16 + geo.safeAreaInsets.leading)
                        .padding(.trailing, 16 + geo.safeAreaInsets.trailing)
                        .padding(.top, 12)

                        // Boss health bar
                        if hud.bossActive, let bossHealth = hud.bossHealth {
                            HStack(spacing: 8) {
                                Image(systemName: "crown.fill")
                                    .foregroundColor(Theme.gold)
                                GeometryReader { barGeo in
                                    ZStack(alignment: .leading) {
                                        RoundedRectangle(cornerRadius: 6)
                                            .fill(Color.black.opacity(0.5))
                                        RoundedRectangle(cornerRadius: 6)
                                            .fill(Color.red)
                                            .frame(width: barGeo.size.width * max(0, min(1, bossHealth)))
                                    }
                                }
                                .frame(height: 14)
                            }
                            .padding(.leading, 24 + geo.safeAreaInsets.leading)
                            .padding(.trailing, 24 + geo.safeAreaInsets.trailing)
                            .padding(.top, 8)
                        }

                        Spacer()
                    }
                    .allowsHitTesting(false)
                }

                // Pause overlay.
                // v1.4 proof (item 3): this SwiftUI overlay MAY intercept
                // touches — and that is safe here, because it only exists
                // when phase == .paused, and the onChange handler above
                // sets scene.isPaused = true for every non-playing phase.
                // While paused, update() does not run and gameplay input
                // is meaningless, so there is no gameplay touch for the
                // overlay to steal. The same holds for the complete and
                // game-over overlays below. During .playing the ONLY
                // SwiftUI layer above the SpriteView is the display-only
                // HUD, which has .allowsHitTesting(false). All gameplay
                // controls (left/right/jump/attack/dodge/pause) are SKNode
                // children of the camera inside the scene itself.
                if coordinator.phase == .paused {
                    overlayCard {
                        VStack(spacing: 16) {
                            Text("إيقاف مؤقت")
                                .font(.system(size: 30, weight: .bold, design: .rounded))
                                .foregroundColor(Theme.cream)
                            Button("استئناف") {
                                SoundManager.shared.click()
                                resumeGame()
                            }
                            .buttonStyle(PrimaryButtonStyle())
                            Button("إعادة المستوى") {
                                SoundManager.shared.click()
                                restartLevel()
                            }
                            .buttonStyle(SecondaryButtonStyle())
                            Button("الخروج للقائمة") {
                                SoundManager.shared.click()
                                onExit()
                            }
                            .buttonStyle(SecondaryButtonStyle())
                        }
                    }
                }

                // Level complete overlay
                if coordinator.phase == .complete, let result = coordinator.result {
                    overlayCard {
                        VStack(spacing: 14) {
                            Text("اكتمل المستوى!")
                                .font(.system(size: 30, weight: .bold, design: .rounded))
                                .foregroundColor(Theme.cream)
                            StarRow(earned: result.stars)
                            HStack(spacing: 20) {
                                VStack {
                                    Image("coin")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 34, height: 34)
                                    Text("+\(result.coins)")
                                        .font(.system(size: 20, weight: .bold, design: .rounded))
                                        .foregroundColor(.white)
                                }
                                VStack {
                                    Image("gemBlue")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 34, height: 34)
                                    Text("+\(result.gems)")
                                        .font(.system(size: 20, weight: .bold, design: .rounded))
                                        .foregroundColor(.white)
                                }
                                VStack {
                                    Image(systemName: "timer")
                                        .font(.system(size: 28))
                                        .foregroundColor(Theme.muted)
                                    Text(timeString(result.timeTaken))
                                        .font(.system(size: 20, weight: .bold, design: .rounded))
                                        .foregroundColor(.white)
                                }
                            }
                            if level.number < 40 {
                                Button("المستوى التالي") {
                                    SoundManager.shared.click()
                                    onNextLevel(level.number + 1)
                                }
                                .buttonStyle(PrimaryButtonStyle())
                            }
                            Button("إعادة المستوى") {
                                SoundManager.shared.click()
                                restartLevel()
                            }
                            .buttonStyle(SecondaryButtonStyle())
                            Button("قائمة المستويات") {
                                SoundManager.shared.click()
                                onExit()
                            }
                            .buttonStyle(SecondaryButtonStyle())
                        }
                    }
                }

                // Game over overlay
                if coordinator.phase == .gameOver {
                    overlayCard {
                        VStack(spacing: 16) {
                            Text("انتهت اللعبة")
                                .font(.system(size: 30, weight: .bold, design: .rounded))
                                .foregroundColor(Theme.danger)
                            Text("حاول مجددًا — يمكنك فعلها!")
                                .font(.system(size: 17, weight: .medium, design: .rounded))
                                .foregroundColor(Theme.muted)
                            Button("حاول مجددًا") {
                                SoundManager.shared.click()
                                restartLevel()
                            }
                            .buttonStyle(PrimaryButtonStyle())
                            Button("قائمة المستويات") {
                                SoundManager.shared.click()
                                onExit()
                            }
                            .buttonStyle(SecondaryButtonStyle())
                        }
                    }
                }
            }
            .onAppear {
                startLevel(size: sceneSize(for: geo), safeArea: geo.safeAreaInsets)
            }
            .onChange(of: coordinator.phase) { phase in
                if phase == .complete, let result = coordinator.result, !recordedResult {
                    recordedResult = true
                    store.completeLevel(number: result.level, stars: result.stars, coins: result.coins, gems: result.gems)
                }
                // v1.4 — every timer follows isPaused (SpaceQuest
                // `isPaused.didSet` pattern): the music loop stops
                // the moment the game pauses / finishes and restarts
                // on resume. The gameplay timer itself is driven by
                // update(dt:), never by a Timer — there is no Timer in
                // the game loop to stop.
                SoundManager.shared.setPaused(phase != .playing)
                scene?.isPaused = (phase == .paused || phase == .complete || phase == .gameOver)
            }
        }
    }

    // MARK: - Helpers

    private func overlayCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        ZStack {
            Color.black.opacity(0.55)
                .ignoresSafeArea()
            VStack {
                content()
            }
            .padding(28)
            .frame(maxWidth: 420)
            .background(Theme.card)
            .cornerRadius(24)
            .overlay(
                RoundedRectangle(cornerRadius: 24)
                    .stroke(Theme.cardBorder, lineWidth: 1.5)
            )
            .shadow(color: .black.opacity(0.5), radius: 16)
        }
    }

    private func timeString(_ t: TimeInterval) -> String {
        let total = max(0, Int(t))
        return String(format: "%d:%02d", total / 60, total % 60)
    }

    /// Scene size for the real screen: fixed 720pt height, width follows
    /// the screen's aspect so the scene fills the screen with no black
    /// bars and no cropped gameplay. Aspect is clamped so extremely
    /// tall/narrow screens keep a sane field of view.
    private func sceneSize(for geo: GeometryProxy) -> CGSize {
        let height: CGFloat = 720
        let aspect = geo.size.width / max(geo.size.height, 1)
        let clamped = min(max(aspect, 1.5), 2.4)
        return CGSize(width: height * clamped, height: height)
    }

    private func startLevel(size: CGSize, safeArea: EdgeInsets) {
        recordedResult = false
        lastSceneSize = size
        lastSafeArea = safeArea
        input.moveLeft = false
        input.moveRight = false
        coordinator.phase = .playing
        coordinator.result = nil
        let newScene = GameScene(level: level, store: store, input: input, hud: hud, coordinator: coordinator, sceneSize: size, safeAreaInsets: safeArea)
        // v1.3 — anti-freeze: the new scene must never start paused. The
        // onChange handler only clears isPaused when the phase *changes*,
        // so a scene created while the phase is already .playing would
        // never get an explicit unpause; set it here directly.
        newScene.isPaused = false
        scene = newScene
    }

    private func restartLevel() {
        startLevel(size: lastSceneSize, safeArea: lastSafeArea)
    }

    private func resumeGame() {
        coordinator.phase = .playing
        scene?.isPaused = false
    }
}
