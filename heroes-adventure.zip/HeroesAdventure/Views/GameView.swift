import SpriteKit
import SwiftUI

struct GameView: View {
    @EnvironmentObject var store: GameStore
    let level: LevelData
    let onExit: () -> Void
    let onNextLevel: (Int) -> Void

    @StateObject private var input = GameInput()
    @StateObject private var hud = GameHUDState()
    @StateObject private var coordinator = GameCoordinator()
    @State private var scene: GameScene?
    @State private var recordedResult = false

    var body: some View {
        ZStack {
            if let scene = scene {
                SpriteView(scene: scene, options: [.ignoresSiblingOrder])
                    .ignoresSafeArea()
            } else {
                GameBackground()
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
            }

            // HUD + controls (only while playing or paused)
            if coordinator.phase == .playing || coordinator.phase == .paused {
                VStack(spacing: 0) {
                    // Top HUD bar
                    HStack(spacing: 10) {
                        HStack(spacing: 2) {
                            ForEach(0..<hud.maxHearts, id: \.self) { i in
                                Image(systemName: i < hud.hearts ? "heart.fill" : "heart")
                                    .font(.system(size: 20))
                                    .foregroundColor(i < hud.hearts ? .red : Color.white.opacity(0.4))
                            }
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.45))
                        .cornerRadius(20)

                        StatPill(imageName: "coin", value: "\(hud.coins)", isSystemImage: false)
                        StatPill(imageName: "gemBlue", value: "\(hud.gems)", isSystemImage: false)
                        Text(timeString(hud.elapsed))
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.black.opacity(0.45))
                            .cornerRadius(20)

                        Spacer()

                        Text(hud.levelName)
                            .font(.system(size: 16, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.black.opacity(0.45))
                            .cornerRadius(20)

                        Button(action: pauseGame) {
                            Image(systemName: "pause.fill")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                                .frame(width: 44, height: 44)
                                .background(Color.black.opacity(0.45))
                                .clipShape(Circle())
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)

                    // Boss health bar
                    if hud.bossActive, let bossHealth = hud.bossHealth {
                        HStack(spacing: 8) {
                            Image(systemName: "crown.fill")
                                .foregroundColor(Theme.gold)
                            GeometryReader { geo in
                                ZStack(alignment: .leading) {
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(Color.black.opacity(0.5))
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(Color.red)
                                        .frame(width: geo.size.width * max(0, min(1, bossHealth)))
                                }
                            }
                            .frame(height: 14)
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 8)
                    }

                    Spacer()

                    // Bottom touch controls
                    HStack {
                        HStack(spacing: 16) {
                            HoldButton(systemImage: "arrow.left") { held in
                                input.moveLeft = held
                            }
                            HoldButton(systemImage: "arrow.right") { held in
                                input.moveRight = held
                            }
                        }
                        Spacer()
                        HStack(spacing: 16) {
                            RoundActionButton(systemImage: "wind", color: Color(red: 0.35, green: 0.65, blue: 1.0)) {
                                input.pressDodge()
                            }
                            RoundActionButton(systemImage: "sword.fill", color: Color(red: 0.95, green: 0.45, blue: 0.25)) {
                                input.pressAttack()
                            }
                            RoundActionButton(systemImage: "arrow.up", color: Color(red: 0.35, green: 0.75, blue: 0.35)) {
                                input.pressJump()
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 18)
                }
            }

            // Pause overlay
            if coordinator.phase == .paused {
                overlayCard {
                    VStack(spacing: 16) {
                        Text("إيقاف مؤقت")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                            .foregroundColor(Theme.cream)
                        Button("استئناف") {
                            SoundManager.shared.click()
                            resumeGame()
                        }
                        .buttonStyle(PrimaryButtonStyle())
                        Button("إعادة المستوى") {
                            SoundManager.shared.click()
                            restartLevel()
                        }
                        .buttonStyle(SecondaryButtonStyle())
                        Button("الخروج للقائمة") {
                            SoundManager.shared.click()
                            onExit()
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                }
            }

            // Level complete overlay
            if coordinator.phase == .complete, let result = coordinator.result {
                overlayCard {
                    VStack(spacing: 14) {
                        Text("اكتمل المستوى!")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                            .foregroundColor(Theme.cream)
                        StarRow(earned: result.stars)
                        HStack(spacing: 20) {
                            VStack {
                                Image("coin")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 34, height: 34)
                                Text("+\(result.coins)")
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                            }
                            VStack {
                                Image("gemBlue")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 34, height: 34)
                                Text("+\(result.gems)")
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                            }
                            VStack {
                                Image(systemName: "timer")
                                    .font(.system(size: 28))
                                    .foregroundColor(Theme.muted)
                                Text(timeString(result.timeTaken))
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                            }
                        }
                        if level.number < 40 {
                            Button("المستوى التالي") {
                                SoundManager.shared.click()
                                onNextLevel(level.number + 1)
                            }
                            .buttonStyle(PrimaryButtonStyle())
                        }
                        Button("إعادة المستوى") {
                            SoundManager.shared.click()
                            restartLevel()
                        }
                        .buttonStyle(SecondaryButtonStyle())
                        Button("قائمة المستويات") {
                            SoundManager.shared.click()
                            onExit()
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                }
            }

            // Game over overlay
            if coordinator.phase == .gameOver {
                overlayCard {
                    VStack(spacing: 16) {
                        Text("انتهت اللعبة")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                            .foregroundColor(Theme.danger)
                        Text("حاول مجددًا — يمكنك فعلها!")
                            .font(.system(size: 17, weight: .medium, design: .rounded))
                            .foregroundColor(Theme.muted)
                        Button("حاول مجددًا") {
                            SoundManager.shared.click()
                            restartLevel()
                        }
                        .buttonStyle(PrimaryButtonStyle())
                        Button("قائمة المستويات") {
                            SoundManager.shared.click()
                            onExit()
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                }
            }
        }
        .onAppear {
            startLevel()
        }
        .onChange(of: coordinator.phase) { phase in
            if phase == .complete, let result = coordinator.result, !recordedResult {
                recordedResult = true
                store.completeLevel(number: result.level, stars: result.stars, coins: result.coins, gems: result.gems)
            }
            scene?.isPaused = (phase == .paused || phase == .complete || phase == .gameOver)
        }
    }

    // MARK: - Helpers

    private func overlayCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        ZStack {
            Color.black.opacity(0.55)
                .ignoresSafeArea()
            VStack {
                content()
            }
            .padding(28)
            .frame(width: 420)
            .background(Theme.card)
            .cornerRadius(24)
            .overlay(
                RoundedRectangle(cornerRadius: 24)
                    .stroke(Theme.cardBorder, lineWidth: 1.5)
            )
            .shadow(color: .black.opacity(0.5), radius: 16)
        }
    }

    private func timeString(_ t: TimeInterval) -> String {
        let total = max(0, Int(t))
        return String(format: "%d:%02d", total / 60, total % 60)
    }

    private func startLevel() {
        recordedResult = false
        input.moveLeft = false
        input.moveRight = false
        coordinator.phase = .playing
        coordinator.result = nil
        let newScene = GameScene(level: level, store: store, input: input, hud: hud, coordinator: coordinator)
        scene = newScene
    }

    private func restartLevel() {
        startLevel()
    }

    private func pauseGame() {
        coordinator.phase = .paused
    }

    private func resumeGame() {
        coordinator.phase = .playing
    }
}
