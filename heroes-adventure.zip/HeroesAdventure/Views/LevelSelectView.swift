import SwiftUI

struct LevelSelectView: View {
    @EnvironmentObject var store: GameStore
    let onBack: () -> Void
    let onPlay: (LevelData) -> Void

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 5)

    private func worldColor(_ world: Int) -> Color {
        switch world {
        case 1: return Color(red: 0.35, green: 0.75, blue: 0.35)
        case 2: return Color(red: 0.95, green: 0.75, blue: 0.35)
        case 3: return Color(red: 0.55, green: 0.80, blue: 1.0)
        case 4: return Color(red: 1.0, green: 0.45, blue: 0.30)
        default: return Theme.cardBorder
        }
    }

    var body: some View {
        ZStack {
            GameBackground()
            VStack(spacing: 0) {
                // Top bar
                HStack {
                    Button(action: {
                        SoundManager.shared.click()
                        onBack()
                    }) {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 44, height: 44)
                            .background(Color.black.opacity(0.45))
                            .clipShape(Circle())
                    }
                    Text("اختر المستوى")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .foregroundColor(Theme.cream)
                    Spacer()
                    StatPill(imageName: "star.fill", value: "\(store.totalStars)/120", isSystemImage: true)
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 8)

                ScrollView {
                    VStack(spacing: 22) {
                        ForEach(1...4, id: \.self) { world in
                            VStack(alignment: .leading, spacing: 10) {
                                HStack(spacing: 8) {
                                    Circle()
                                        .fill(worldColor(world))
                                        .frame(width: 16, height: 16)
                                    Text("العالم \(world): \(LevelData.all.first { $0.world == world }?.worldName ?? "")")
                                        .font(.system(size: 20, weight: .bold, design: .rounded))
                                        .foregroundColor(Theme.cream)
                                    Spacer()
                                    Text("المستويات \(((world - 1) * 10) + 1) - \(world * 10)")
                                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                                        .foregroundColor(Theme.muted)
                                }
                                .padding(.horizontal, 4)

                                LazyVGrid(columns: columns, spacing: 10) {
                                    ForEach(((world - 1) * 10 + 1)...(world * 10), id: \.self) { n in
                                        levelButton(n)
                                    }
                                }
                            }
                            .padding(.horizontal, 20)
                        }
                    }
                    .padding(.vertical, 12)
                }
            }
        }
    }

    @ViewBuilder
    private func levelButton(_ n: Int) -> some View {
        let locked = n > store.unlockedLevel
        let stars = store.stars(for: n)
        let isBoss = (n % 10 == 0)
        Button(action: {
            guard !locked, let level = LevelData.level(n) else { return }
            SoundManager.shared.click()
            onPlay(level)
        }) {
            VStack(spacing: 4) {
                if locked {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(Color.white.opacity(0.5))
                } else if isBoss {
                    Image(systemName: "crown.fill")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(Theme.gold)
                } else {
                    Text("\(n)")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
                HStack(spacing: 2) {
                    ForEach(1...3, id: \.self) { i in
                        Image(systemName: i <= stars ? "star.fill" : "star")
                            .font(.system(size: 9))
                            .foregroundColor(i <= stars ? Theme.gold : Color.white.opacity(0.3))
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 64)
            .background(locked ? Color.black.opacity(0.35) : Theme.card)
            .cornerRadius(14)
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(isBoss && !locked ? Theme.gold : Theme.cardBorder, lineWidth: isBoss && !locked ? 2 : 1)
            )
        }
        .disabled(locked)
    }
}
