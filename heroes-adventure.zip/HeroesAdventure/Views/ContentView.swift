import SwiftUI

/// Root screen state machine. No NavigationStack — every transition is
/// explicit, so the back stack can never get into a bad state.
enum Screen {
    case menu
    case levels
    case shop
    case settings
    case game(LevelData)
}

struct ContentView: View {
    @EnvironmentObject var store: GameStore
    @State private var screen: Screen = .menu
    @State private var showDailyBonus = false

    var body: some View {
        ZStack {
            switch screen {
            case .menu:
                MainMenuView(
                    onPlay: { screen = .levels },
                    onShop: { screen = .shop },
                    onSettings: { screen = .settings }
                )
            case .levels:
                LevelSelectView(
                    onBack: { screen = .menu },
                    onPlay: { level in screen = .game(level) }
                )
            case .shop:
                ShopView(onBack: { screen = .menu })
            case .settings:
                SettingsView(onBack: { screen = .menu })
            case .game(let level):
                GameView(
                    level: level,
                    onExit: { screen = .levels },
                    onNextLevel: { next in
                        if let nextLevel = LevelData.level(next) {
                            screen = .game(nextLevel)
                        } else {
                            screen = .levels
                        }
                    }
                )
                // v1.3: a new level must get a fresh GameView (fresh
                // @StateObjects and a fresh onAppear -> startLevel). Without
                // .id, SwiftUI reuses the GameView when only `level`
                // changes, so the old scene keeps running and the new level
                // never starts.
                .id(level.number)
            }
        }
        .onAppear {
            SoundManager.shared.configure(soundOn: store.soundOn, musicOn: store.musicOn)
            if store.canClaimDailyBonus {
                showDailyBonus = true
            }
        }
        .onChange(of: store.soundOn) { _ in
            SoundManager.shared.configure(soundOn: store.soundOn, musicOn: store.musicOn)
        }
        .onChange(of: store.musicOn) { _ in
            SoundManager.shared.configure(soundOn: store.soundOn, musicOn: store.musicOn)
        }
        .alert("مكافأة يومية!", isPresented: $showDailyBonus) {
            Button("استلام +100 عملة و +10 جواهر") {
                _ = store.claimDailyBonus()
                SoundManager.shared.chest()
            }
            Button("لاحقًا", role: .cancel) { }
        } message: {
            Text("عُد كل يوم واحصل على مكافأتك.")
        }
    }
}
