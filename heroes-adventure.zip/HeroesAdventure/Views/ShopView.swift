import SwiftUI

struct ShopView: View {
    @EnvironmentObject var store: GameStore
    let onBack: () -> Void

    @State private var message: String?

    var body: some View {
        ZStack {
            GameBackground()
            VStack(spacing: 0) {
                HStack {
                    Button(action: {
                        SoundManager.shared.click()
                        onBack()
                    }) {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 44, height: 44)
                            .background(Color.black.opacity(0.45))
                            .clipShape(Circle())
                    }
                    Text("المتجر")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .foregroundColor(Theme.cream)
                    Spacer()
                    StatPill(imageName: "coin", value: "\(store.coins)", isSystemImage: false)
                    StatPill(imageName: "gemBlue", value: "\(store.gems)", isSystemImage: false)
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 8)

                if let message = message {
                    Text(message)
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .foregroundColor(Theme.gold)
                        .padding(.bottom, 6)
                }

                ScrollView {
                    VStack(spacing: 22) {
                        // Upgrades
                        VStack(alignment: .leading, spacing: 10) {
                            SectionHeader(title: "ترقيات")
                            ForEach(GameStore.shopItems) { item in
                                shopRow(item)
                            }
                        }
                        .padding(.horizontal, 20)

                        // Heroes
                        VStack(alignment: .leading, spacing: 10) {
                            SectionHeader(title: "الأبطال")
                            Text("اختر بطلك — يتغير لونه في اللعبة.")
                                .font(.system(size: 14, weight: .medium, design: .rounded))
                                .foregroundColor(Theme.muted)
                                .padding(.horizontal, 4)
                            ForEach(GameStore.heroSkins) { skin in
                                heroRow(skin)
                            }
                        }
                        .padding(.horizontal, 20)

                        Text("عملات اللعبة تُكتسب من اللعب فقط في هذه النسخة التجريبية — لا يوجد شراء حقيقي.")
                            .font(.system(size: 13, weight: .medium, design: .rounded))
                            .foregroundColor(Theme.muted)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 32)
                            .padding(.bottom, 24)
                    }
                    .padding(.vertical, 8)
                }
            }
        }
    }

    private func priceText(_ item: ShopItem) -> String {
        if item.costGems > 0 { return "\(item.costGems) جوهرة" }
        return "\(item.costCoins) عملة"
    }

    @ViewBuilder
    private func shopRow(_ item: ShopItem) -> some View {
        let owned = store.ownedItems.contains(item.id)
        let affordable = store.canBuy(item)
        HStack(spacing: 12) {
            Image(systemName: icon(for: item.kind))
                .font(.system(size: 24))
                .foregroundColor(Theme.gold)
                .frame(width: 44, height: 44)
                .background(Color.black.opacity(0.3))
                .cornerRadius(12)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundColor(Theme.cream)
                Text(item.detail)
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(Theme.muted)
            }
            Spacer()
            Button(owned ? "مملوكة" : priceText(item)) {
                if store.buy(item) {
                    message = "تم الشراء: \(item.name)"
                    SoundManager.shared.chest()
                } else {
                    message = "لا تملك ما يكفي أو تحتاج الترقية السابقة"
                    SoundManager.shared.hurt()
                }
            }
            .font(.system(size: 15, weight: .bold, design: .rounded))
            .foregroundColor(owned ? Theme.muted : .white)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(owned ? Color.black.opacity(0.3) : (affordable ? Theme.goldDark : Color.gray.opacity(0.5)))
            .cornerRadius(12)
            .disabled(owned)
        }
        .padding(12)
        .background(Theme.card)
        .cornerRadius(Theme.corner)
    }

    @ViewBuilder
    private func heroRow(_ skin: HeroSkin) -> some View {
        let equipped = store.equippedHero == skin.id
        HStack(spacing: 12) {
            Image("hero")
                .resizable()
                .scaledToFit()
                .frame(width: 34, height: 44)
                .colorMultiply(GameStore.tintColor(for: skin.id))
                .background(Color.black.opacity(0.3))
                .cornerRadius(12)
            VStack(alignment: .leading, spacing: 2) {
                Text(skin.name)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundColor(Theme.cream)
                Text(skin.costGems == 0 ? "مجاني" : "\(skin.costGems) جوهرة")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(Theme.muted)
            }
            Spacer()
            Button(equipped ? "مجهز" : "اختيار") {
                if store.buyHero(skin) {
                    message = "تم تجهيز: \(skin.name)"
                    SoundManager.shared.click()
                } else {
                    message = "لا تملك جواهر كافية"
                    SoundManager.shared.hurt()
                }
            }
            .font(.system(size: 15, weight: .bold, design: .rounded))
            .foregroundColor(equipped ? Theme.muted : .white)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(equipped ? Color.black.opacity(0.3) : Theme.goldDark)
            .cornerRadius(12)
        }
        .padding(12)
        .background(Theme.card)
        .cornerRadius(Theme.corner)
    }

    private func icon(for kind: ShopItem.Kind) -> String {
        switch kind {
        case .sword: return "sword.fill"
        case .armor: return "shield.fill"
        case .ability: return "bolt.fill"
        }
    }
}
