import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: GameStore
    let onBack: () -> Void

    @State private var showResetConfirm = false
    @State private var resetDone = false

    var body: some View {
        ZStack {
            GameBackground()
            VStack(spacing: 0) {
                HStack {
                    Button(action: {
                        SoundManager.shared.click()
                        onBack()
                    }) {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 44, height: 44)
                            .background(Color.black.opacity(0.45))
                            .clipShape(Circle())
                    }
                    Text("الإعدادات")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .foregroundColor(Theme.cream)
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                .padding(.bottom, 8)

                VStack(spacing: 14) {
                    Toggle(isOn: $store.soundOn) {
                        Label("المؤثرات الصوتية", systemImage: "speaker.wave.2.fill")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .foregroundColor(Theme.cream)
                    }
                    .toggleStyle(SwitchToggleStyle(tint: Theme.gold))
                    .padding(16)
                    .background(Theme.card)
                    .cornerRadius(Theme.corner)

                    Toggle(isOn: $store.musicOn) {
                        Label("الموسيقى", systemImage: "music.note")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .foregroundColor(Theme.cream)
                    }
                    .toggleStyle(SwitchToggleStyle(tint: Theme.gold))
                    .padding(16)
                    .background(Theme.card)
                    .cornerRadius(Theme.corner)

                    HStack {
                        Label("المكافأة اليومية", systemImage: "gift.fill")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .foregroundColor(Theme.cream)
                        Spacer()
                        Text(store.canClaimDailyBonus ? "متاحة الآن" : "عُد غدًا")
                            .font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundColor(store.canClaimDailyBonus ? Theme.gold : Theme.muted)
                    }
                    .padding(16)
                    .background(Theme.card)
                    .cornerRadius(Theme.corner)

                    Button("إعادة تعيين التقدم") {
                        showResetConfirm = true
                    }
                    .buttonStyle(SecondaryButtonStyle())
                    .foregroundColor(Theme.danger)

                    if resetDone {
                        Text("تمت إعادة التعيين")
                            .font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundColor(Theme.gold)
                    }

                    Spacer()

                    Text("مغامرة الأبطال — الإصدار 1.4\nلعبة كاملة بلا إنترنت وبلا حساب")
                        .font(.system(size: 14, weight: .medium, design: .rounded))
                        .foregroundColor(Theme.muted)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, 48)
                .padding(.vertical, 16)
            }
        }
        .alert("إعادة تعيين التقدم؟", isPresented: $showResetConfirm) {
            Button("إعادة تعيين", role: .destructive) {
                store.resetProgress()
                resetDone = true
            }
            Button("إلغاء", role: .cancel) { }
        } message: {
            Text("سيُحذف كل التقدم والعملات والجواهر والترقيات.")
        }
    }
}
