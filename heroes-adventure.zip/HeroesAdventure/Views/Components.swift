import SwiftUI

/// Shared theme: exact colors, exact metrics. Every screen uses these so
/// the UI is pixel-aligned and consistent.
enum Theme {
    static let bgTop = Color(red: 0.05, green: 0.16, blue: 0.10)
    static let bgBottom = Color(red: 0.02, green: 0.07, blue: 0.05)
    static let card = Color(red: 0.10, green: 0.22, blue: 0.15)
    static let cardBorder = Color(red: 0.35, green: 0.65, blue: 0.40)
    static let gold = Color(red: 1.0, green: 0.80, blue: 0.25)
    static let goldDark = Color(red: 0.85, green: 0.60, blue: 0.10)
    static let cream = Color(red: 1.0, green: 0.97, blue: 0.88)
    static let muted = Color(red: 0.75, green: 0.85, blue: 0.78)
    static let danger = Color(red: 0.95, green: 0.35, blue: 0.30)
    static let sky = Color(red: 0.45, green: 0.75, blue: 1.0)

    static let corner: CGFloat = 16
    static let buttonHeight: CGFloat = 56
    static let controlSize: CGFloat = 64
}

/// Big professional primary button: gold gradient, dark bold text, shadow.
struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 20, weight: .bold, design: .rounded))
            .foregroundColor(Color(red: 0.20, green: 0.12, blue: 0.02))
            .frame(height: Theme.buttonHeight)
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(
                    colors: [Theme.gold, Theme.goldDark],
                    startPoint: .top, endPoint: .bottom
                )
            )
            .cornerRadius(Theme.corner)
            .shadow(color: .black.opacity(0.45), radius: 6, x: 0, y: 3)
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
    }
}

/// Secondary button: dark card, light text, thin border.
struct SecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 18, weight: .semibold, design: .rounded))
            .foregroundColor(Theme.cream)
            .frame(height: Theme.buttonHeight)
            .frame(maxWidth: .infinity)
            .background(Theme.card)
            .cornerRadius(Theme.corner)
            .overlay(
                RoundedRectangle(cornerRadius: Theme.corner)
                    .stroke(Theme.cardBorder, lineWidth: 1.5)
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
    }
}

/// A press-and-hold button (for left/right movement). Calls onChange(true)
/// while held and onChange(false) on release.
struct HoldButton: View {
    let systemImage: String
    let onChange: (Bool) -> Void

    @State private var held = false

    var body: some View {
        Image(systemName: systemImage)
            .font(.system(size: 28, weight: .bold))
            .foregroundColor(.white)
            .frame(width: Theme.controlSize, height: Theme.controlSize)
            .background(held ? Color.white.opacity(0.35) : Color.black.opacity(0.45))
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.white.opacity(0.6), lineWidth: 2))
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { _ in
                        if !held {
                            held = true
                            onChange(true)
                        }
                    }
                    .onEnded { _ in
                        held = false
                        onChange(false)
                    }
            )
    }
}

/// A round tap button (jump / attack / dodge).
struct RoundActionButton: View {
    let systemImage: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemImage)
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(.white)
                .frame(width: Theme.controlSize, height: Theme.controlSize)
                .background(color.opacity(0.85))
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.7), lineWidth: 2))
                .shadow(color: .black.opacity(0.4), radius: 4, x: 0, y: 2)
        }
    }
}

/// Small pill showing an icon image plus a number (HUD).
struct StatPill: View {
    let imageName: String
    let value: String
    let isSystemImage: Bool

    var body: some View {
        HStack(spacing: 6) {
            if isSystemImage {
                Image(systemName: imageName)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
            } else {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 26, height: 26)
            }
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundColor(.white)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.black.opacity(0.45))
        .cornerRadius(20)
    }
}

/// Three-star row (filled = earned, dim = not earned).
struct StarRow: View {
    let earned: Int

    var body: some View {
        HStack(spacing: 8) {
            ForEach(1...3, id: \.self) { i in
                Image(systemName: i <= earned ? "star.fill" : "star")
                    .font(.system(size: 34))
                    .foregroundColor(i <= earned ? Theme.gold : Color.white.opacity(0.35))
            }
        }
    }
}

/// Section header used across menu screens.
struct SectionHeader: View {
    let title: String

    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(Theme.cream)
            Spacer()
        }
        .padding(.horizontal, 4)
    }
}

/// App background: dark green gradient, used on every menu screen.
struct GameBackground: View {
    var body: some View {
        LinearGradient(
            colors: [Theme.bgTop, Theme.bgBottom],
            startPoint: .top, endPoint: .bottom
        )
        .ignoresSafeArea()
    }
}
