import SwiftUI

struct MainMenuView: View {
    @EnvironmentObject var store: GameStore
    let onPlay: () -> Void
    let onShop: () -> Void
    let onSettings: () -> Void

    var body: some View {
        GeometryReader { geo in
            // Landscape menu (v1.3). v1.2 used fixed-percentage columns
            // (44% + 42%) with the two bottom buttons side by side in an
            // inner HStack; on the user's device the "الإعدادات" button was
            // cut off at the left edge (only "الإ" visible) and the menu
            // buttons did not respond. The fixed-percentage math cannot
            // overflow on paper, so the layout is rebuilt to be robust by
            // construction instead of by arithmetic:
            //  - the three buttons are stacked VERTICALLY, each full width
            //    of the buttons column — no inner HStack, so no button can
            //    ever be cut off horizontally;
            //  - both columns are sized from the available width with a
            //    hard clamp (heroW + btnW + gap == availW, never more), so
            //    the row can never exceed the screen;
            //  - the background layers are explicitly non-hit-testable, so
            //    nothing above the buttons can swallow a tap.
            // Same visual identity (same hero, title, colours, buttons) —
            // only the layout changed.
            let w = geo.size.width
            let h = geo.size.height
            let topBar: CGFloat = 44
            let contentH = h - topBar - 16
            let heroH = min(190, max(90, contentH * 0.62))
            let titleSize = min(40, max(26, contentH * 0.13))
            let subSize = min(16, max(12, contentH * 0.045))
            // Widths that cannot overflow: available width after the outer
            // padding AND the safe area, split by a fixed gap; hero takes
            // at most 52% of it. v1.4: the safe area is subtracted here
            // (notch / Dynamic Island in landscape can be ~47pt a side),
            // so heroW + btnW + gap + outerPad + safeArea == w exactly.
            let safeL = geo.safeAreaInsets.leading
            let safeR = geo.safeAreaInsets.trailing
            let outerPad: CGFloat = 24
            let colGap: CGFloat = 24
            let availW = max(w - outerPad * 2 - safeL - safeR, 320)
            let heroW = min(w * 0.44, (availW - colGap) * 0.52)
            let btnW = availW - colGap - heroW

            ZStack {
                GameBackground()
                    .allowsHitTesting(false)
                Image("backgroundForest")
                    .resizable()
                    .scaledToFill()
                    .opacity(0.35)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)

                VStack(spacing: 0) {
                    // Top bar: currency
                    HStack(spacing: 12) {
                        StatPill(imageName: "coin", value: "\(store.coins)", isSystemImage: false)
                        StatPill(imageName: "gemBlue", value: "\(store.gems)", isSystemImage: false)
                        Spacer()
                        HStack(spacing: 4) {
                            Image(systemName: "star.fill")
                                .foregroundColor(Theme.gold)
                            Text("\(store.totalStars)/120")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.45))
                        .cornerRadius(20)
                    }
                    .padding(.leading, 20 + safeL)
                    .padding(.trailing, 20 + safeR)
                    .padding(.top, 12)
                    .frame(height: topBar)

                    // Two columns: hero + title | buttons
                    HStack(alignment: .center, spacing: colGap) {
                        // Left: hero + title + subtitle
                        VStack(spacing: 6) {
                            Image("hero")
                                .resizable()
                                .scaledToFit()
                                .frame(height: heroH)
                            Text("مغامرة الأبطال")
                                .font(.system(size: titleSize, weight: .black, design: .rounded))
                                .foregroundColor(Theme.cream)
                                .shadow(color: .black.opacity(0.6), radius: 4, x: 0, y: 2)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                            Text("40 مستوى • 4 عوالم • زعماء • كنوز")
                                .font(.system(size: subSize, weight: .semibold, design: .rounded))
                                .foregroundColor(Theme.muted)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                        }
                        .frame(width: heroW)

                        // Right: buttons, stacked vertically, each full
                        // width — a full-width button cannot be cut off.
                        VStack(spacing: 12) {
                            Button(action: {
                                SoundManager.shared.click()
                                onPlay()
                            }) {
                                Text("العب")
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.6)
                            }
                            .buttonStyle(PrimaryButtonStyle())

                            Button(action: {
                                SoundManager.shared.click()
                                onShop()
                            }) {
                                Text("المتجر")
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.6)
                            }
                            .buttonStyle(SecondaryButtonStyle())

                            Button(action: {
                                SoundManager.shared.click()
                                onSettings()
                            }) {
                                Text("الإعدادات")
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.6)
                            }
                            .buttonStyle(SecondaryButtonStyle())
                        }
                        .frame(width: btnW)
                    }
                    .padding(.leading, outerPad + safeL)
                    .padding(.trailing, outerPad + safeR)
                    .frame(maxHeight: .infinity)
                }
            }
        }
    }
}
