import SwiftUI

struct MainMenuView: View {
    @EnvironmentObject var store: GameStore
    let onPlay: () -> Void
    let onShop: () -> Void
    let onSettings: () -> Void

    var body: some View {
        ZStack {
            GameBackground()
            Image("backgroundForest")
                .resizable()
                .scaledToFill()
                .opacity(0.35)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                // Top bar: currency
                HStack(spacing: 12) {
                    StatPill(imageName: "coin", value: "\(store.coins)", isSystemImage: false)
                    StatPill(imageName: "gemBlue", value: "\(store.gems)", isSystemImage: false)
                    Spacer()
                    HStack(spacing: 4) {
                        Image(systemName: "star.fill")
                            .foregroundColor(Theme.gold)
                        Text("\(store.totalStars)/120")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.45))
                    .cornerRadius(20)
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)

                Spacer()

                // Hero + title
                Image("hero")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 170)
                Text("مغامرة الأبطال")
                    .font(.system(size: 44, weight: .black, design: .rounded))
                    .foregroundColor(Theme.cream)
                    .shadow(color: .black.opacity(0.6), radius: 4, x: 0, y: 2)
                Text("40 مستوى • 4 عوالم • زعماء • كنوز")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                    .foregroundColor(Theme.muted)
                    .padding(.top, 4)

                Spacer()

                // Buttons
                VStack(spacing: 14) {
                    Button("العب") {
                        SoundManager.shared.click()
                        onPlay()
                    }
                    .buttonStyle(PrimaryButtonStyle())

                    HStack(spacing: 14) {
                        Button("المتجر") {
                            SoundManager.shared.click()
                            onShop()
                        }
                        .buttonStyle(SecondaryButtonStyle())

                        Button("الإعدادات") {
                            SoundManager.shared.click()
                            onSettings()
                        }
                        .buttonStyle(SecondaryButtonStyle())
                    }
                }
                .padding(.horizontal, 48)
                .padding(.bottom, 28)
            }
        }
    }
}
