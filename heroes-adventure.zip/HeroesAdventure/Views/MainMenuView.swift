import SwiftUI

struct MainMenuView: View {
    @EnvironmentObject var store: GameStore
    let onPlay: () -> Void
    let onShop: () -> Void
    let onSettings: () -> Void

    var body: some View {
        GeometryReader { geo in
            // Adaptive sizing: the v1.0 menu used fixed sizes (170pt hero,
            // 44pt title) needing ~464pt of height, but a landscape iPhone
            // is only ~375-430pt tall, so the bottom buttons were clipped
            // off-screen. Hero and title now scale to the real height so
            // the whole menu always fits.
            let h = geo.size.height
            let heroHeight = min(170, max(64, h * 0.28))
            let titleSize = min(44, max(28, h * 0.11))
            let subSize = min(17, max(13, h * 0.042))
            let bottomPad: CGFloat = h < 400 ? 14 : 28
            let btnSpacing: CGFloat = h < 400 ? 10 : 14

            ZStack {
                GameBackground()
                Image("backgroundForest")
                    .resizable()
                    .scaledToFill()
                    .opacity(0.35)
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    // Top bar: currency
                    HStack(spacing: 12) {
                        StatPill(imageName: "coin", value: "\(store.coins)", isSystemImage: false)
                        StatPill(imageName: "gemBlue", value: "\(store.gems)", isSystemImage: false)
                        Spacer()
                        HStack(spacing: 4) {
                            Image(systemName: "star.fill")
                                .foregroundColor(Theme.gold)
                            Text("\(store.totalStars)/120")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.45))
                        .cornerRadius(20)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 16)

                    Spacer()

                    // Hero + title
                    Image("hero")
                        .resizable()
                        .scaledToFit()
                        .frame(height: heroHeight)
                    Text("مغامرة الأبطال")
                        .font(.system(size: titleSize, weight: .black, design: .rounded))
                        .foregroundColor(Theme.cream)
                        .shadow(color: .black.opacity(0.6), radius: 4, x: 0, y: 2)
                    Text("40 مستوى • 4 عوالم • زعماء • كنوز")
                        .font(.system(size: subSize, weight: .semibold, design: .rounded))
                        .foregroundColor(Theme.muted)
                        .padding(.top, 4)

                    Spacer()

                    // Buttons
                    VStack(spacing: btnSpacing) {
                        Button("العب") {
                            SoundManager.shared.click()
                            onPlay()
                        }
                        .buttonStyle(PrimaryButtonStyle())

                        HStack(spacing: btnSpacing) {
                            Button("المتجر") {
                                SoundManager.shared.click()
                                onShop()
                            }
                            .buttonStyle(SecondaryButtonStyle())

                            Button("الإعدادات") {
                                SoundManager.shared.click()
                                onSettings()
                            }
                            .buttonStyle(SecondaryButtonStyle())
                        }
                    }
                    .padding(.horizontal, 48)
                    .padding(.bottom, bottomPad)
                }
            }
        }
    }
}
