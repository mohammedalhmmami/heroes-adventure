import SwiftUI

struct MainMenuView: View {
    @EnvironmentObject var store: GameStore
    let onPlay: () -> Void
    let onShop: () -> Void
    let onSettings: () -> Void

    var body: some View {
        GeometryReader { geo in
            // Landscape menu (v1.2). The gameplay page fills the screen
            // edge to edge, and the menu must do the same. A portrait-style
            // centred column squeezed into a ~390pt-tall landscape screen
            // clipped the bottom buttons (v1.0) and left the settings
            // button's text missing on device (v1.1). The menu is now a
            // two-column landscape layout: hero + title on the left,
            // buttons on the right. Every size is derived from the real
            // screen height/width, so nothing is clipped and nothing is
            // empty on any landscape iPhone. Same visual identity (same
            // hero, title, colours, buttons) — only the layout changed.
            //
            // Height budget on a 390pt-tall screen: top bar 44 + content
            // 346. Left column: hero 190 + title ~40 + subtitle ~16 +
            // spacing 12 = ~258 < 346. Right column: 56 + 12 + 56 = 124.
            // Width budget on an 844pt-wide screen: 44% + 42% + 24 spacing
            // + 48 padding = ~797 < 844. Both bottom buttons get ~171pt
            // each — "الإعدادات" needs ~130pt at 18pt, so it fits, and
            // every label also has lineLimit(1) + minimumScaleFactor so
            // text shrinks instead of ever disappearing.
            let w = geo.size.width
            let h = geo.size.height
            let topBar: CGFloat = 44
            let contentH = h - topBar - 16
            let heroH = min(190, max(90, contentH * 0.62))
            let titleSize = min(40, max(26, contentH * 0.13))
            let subSize = min(16, max(12, contentH * 0.045))

            ZStack {
                GameBackground()
                Image("backgroundForest")
                    .resizable()
                    .scaledToFill()
                    .opacity(0.35)
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    // Top bar: currency
                    HStack(spacing: 12) {
                        StatPill(imageName: "coin", value: "\(store.coins)", isSystemImage: false)
                        StatPill(imageName: "gemBlue", value: "\(store.gems)", isSystemImage: false)
                        Spacer()
                        HStack(spacing: 4) {
                            Image(systemName: "star.fill")
                                .foregroundColor(Theme.gold)
                            Text("\(store.totalStars)/120")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.45))
                        .cornerRadius(20)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    .frame(height: topBar)

                    // Two columns: hero + title | buttons
                    HStack(alignment: .center, spacing: 24) {
                        // Left: hero + title + subtitle
                        VStack(spacing: 6) {
                            Image("hero")
                                .resizable()
                                .scaledToFit()
                                .frame(height: heroH)
                            Text("مغامرة الأبطال")
                                .font(.system(size: titleSize, weight: .black, design: .rounded))
                                .foregroundColor(Theme.cream)
                                .shadow(color: .black.opacity(0.6), radius: 4, x: 0, y: 2)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                            Text("40 مستوى • 4 عوالم • زعماء • كنوز")
                                .font(.system(size: subSize, weight: .semibold, design: .rounded))
                                .foregroundColor(Theme.muted)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                        }
                        .frame(width: w * 0.44)

                        // Right: buttons
                        VStack(spacing: 12) {
                            Button(action: {
                                SoundManager.shared.click()
                                onPlay()
                            }) {
                                Text("العب")
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.6)
                            }
                            .buttonStyle(PrimaryButtonStyle())

                            HStack(spacing: 12) {
                                Button(action: {
                                    SoundManager.shared.click()
                                    onShop()
                                }) {
                                    Text("المتجر")
                                        .lineLimit(1)
                                        .minimumScaleFactor(0.6)
                                }
                                .buttonStyle(SecondaryButtonStyle())

                                Button(action: {
                                    SoundManager.shared.click()
                                    onSettings()
                                }) {
                                    Text("الإعدادات")
                                        .lineLimit(1)
                                        .minimumScaleFactor(0.6)
                                }
                                .buttonStyle(SecondaryButtonStyle())
                            }
                        }
                        .frame(width: w * 0.42)
                    }
                    .padding(.horizontal, 24)
                    .frame(maxHeight: .infinity)
                }
            }
        }
    }
}
